<?php

class envato_content_import extends WP_Import
{
	function check()
	{
		//you can add any extra custom functions after the importing of demo coment is done

		return true;
	}
}