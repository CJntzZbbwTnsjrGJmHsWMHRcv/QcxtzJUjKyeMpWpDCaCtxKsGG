<?php
$all_data = cspt_get_all_option_array();
extract($all_data);
$gradient_first = '#ffff00';
$gradient_last  = '#ffff00';
if( function_exists('cspt_get_base_option') ){
	$gradient_colors = cspt_get_base_option('gradient-color');
	$gradient_first  = ( !empty($gradient_colors['first']) ) ? $gradient_colors['first'] : '#ffff00' ;
	$gradient_last   = ( !empty($gradient_colors['last'])  ) ? $gradient_colors['last']  : '#ffff00' ;
}
?>
<?php echo cspt_all_options_values('background'); ?>
<?php echo cspt_all_options_values('typography'); ?>
/* --------------------------------------
 * Custom background color and text color
 * ---------------------------------------*/
/* Custom preheader background color */
.cspt-pre-header-wrapper.cspt-bg-color-custom{
	background-color: <?php echo esc_attr($preheader_bgcolor_custom); ?>;
}
/* Custom Header background color */
.cspt-header-wrapper.cspt-bg-color-custom{
	background-color: <?php echo esc_attr($header_background_color); ?>;
}
/* Custom Menu area background color */
.cspt-header-menu-area.cspt-bg-color-custom{
	background-color: <?php echo esc_attr($menu_background_color); ?>;
}
/* sticky-header-background-color */
.cspt-sticky-on.cspt-sticky-bg-color-custom{
	background-color: <?php echo esc_attr($sticky_header_background_color); ?>;
}
/* Custom Menu text color */
.cspt-sticky-on .cspt-navbar div > ul > li > a{
	color: <?php echo esc_attr($main_menu_sticky_color); ?>;
}
<?php if($service_single_image_hide==true){ ?>
/* Hide single image in service */
.single.single-cspt-service .cspt-featured-wrapper {
	display: none;
}

<?php } ?>
/* --------------------------------------
 * A tag
 * ---------------------------------------*/
a{
	color: <?php echo esc_attr($link_color['normal']); ?>
}
a:hover{
	color: <?php echo esc_attr($link_color['hover']); ?>
}

/* --------------------------------------
 * site-title
 * ---------------------------------------*/
.site-title {
    height: <?php echo esc_attr($header_height); ?>px;
}
.site-title img.cspt-main-logo{
	max-height: <?php echo esc_attr($logo_height); ?>px;
}
.site-title img.cspt-responsive-logo{
	max-height: <?php echo esc_attr($responsive_logo_height); ?>px;
}

/* --------------------------------------
 * Titlebar
 * ---------------------------------------*/
.cspt-title-bar-content,
.cspt-title-bar-wrapper{
    min-height: <?php echo esc_attr($titlebar_height); ?>px;
}
.cspt-color-globalcolor,
.cspt-globalcolor,
.globalcolor{
	color: <?php echo esc_attr($global_color); ?> ;
}
.cspt-bg-color-globalcolor.cspt-title-bar-wrapper:before,
.creativesplanet-ele-team .creativesplanet-overlay{
	background-color: <?php echo cspt_hex2rgb($global_color, '0.5') ?>;
}

/*========================================== Row / Colum Background Base Css ==========================================*/

.elementor-section.elementor-top-section.cspt-bg-image-over-color.cspt-bgimage-yes:before,
.elementor-column.elementor-top-column.cspt-bgimage-yes.cspt-bg-image-over-color > .cspt-stretched-div:before,

.elementor-column.elementor-top-column.cspt-bg-image-over-color > .elementor-widget-wrap:before,
.elementor-column.elementor-inner-column.cspt-bg-image-over-color > .elementor-widget-wrap:before,

.elementor-element.elementor-section.elementor-inner-section.cspt-bg-image-over-color.cspt-bgimage-yes:before{
	background-color: transparent !important;
}

/* --------------------------------------
 * Row Colum - Global BG Color
 * ---------------------------------------*/
/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-globalcolor,
.elementor-section.elementor-top-section.cspt-elementor-bg-color-globalcolor:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-globalcolor{
	background-color: <?php echo esc_attr($global_color); ?>;
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor:not(.cspt-bgimage-yes) .elementor-widget-wrap > .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor.cspt-bg-image-over-color .elementor-widget-wrap > .cspt-stretched-div,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-globalcolor.cspt-bg-image-over-color:before,

/*--- Second Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-globalcolor:not(.cspt-bgimage-yes) > .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-globalcolor.cspt-bg-image-over-color > .elementor-widget-wrap{
	background-color: <?php echo esc_attr($global_color); ?> !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-globalcolor.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor.cspt-bgimage-yes:not(.cspt-col-stretched-yes) > .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor.cspt-bgimage-yes:not(.cspt-bg-image-over-color) .elementor-widget-wrap .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-globalcolor .elementor-widget-wrap .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-globalcolor.cspt-bg-color-over-image:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-globalcolor.cspt-bgimage-yes > .elementor-widget-wrap:before{
    background-color: <?php echo cspt_hex2rgb($global_color, '0.90') ?>;
}
/*====== End --- Row Colum - Global BG Color ======*/

/* --------------------------------------
 * Row Colum - Light BG Color
 * ---------------------------------------*/
/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-light,
.elementor-section.elementor-top-section.cspt-elementor-bg-color-light:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-light{
	background-color: <?php echo esc_attr($light_bg_color); ?>;
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light:not(.cspt-bgimage-yes) .elementor-widget-wrap > .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light.cspt-bg-image-over-color .elementor-widget-wrap > .cspt-stretched-div,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-light:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-light.cspt-bg-image-over-color:before,

/*--- Second Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-light:not(.cspt-bgimage-yes) > .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-light.cspt-bg-image-over-color > .elementor-widget-wrap{
	background-color: <?php echo esc_attr($light_bg_color); ?> !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-light.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light.cspt-bgimage-yes:not(.cspt-col-stretched-yes) > .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light.cspt-bgimage-yes:not(.cspt-bg-image-over-color) .elementor-widget-wrap .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-light .elementor-widget-wrap .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-light.cspt-bg-color-over-image:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-light.cspt-bgimage-yes > .elementor-widget-wrap:before{
    background-color: <?php echo cspt_hex2rgb($light_bg_color, '0.60') ?>;
}
/*====== End --- Row Colum - Light BG Color ======*/

/* --------------------------------------
 * Row Colum - Secondary BG Color
 * ---------------------------------------*/
/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-secondary,
.elementor-section.elementor-top-section.cspt-elementor-bg-color-secondary:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-secondary{
	background-color: <?php echo esc_attr($secondary_color); ?>;
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary:not(.cspt-bgimage-yes) .elementor-widget-wrap > .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary.cspt-bg-image-over-color .elementor-widget-wrap > .cspt-stretched-div,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-secondary.cspt-bg-image-over-color:before,

/*--- Second Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-secondary:not(.cspt-bgimage-yes) > .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-secondary.cspt-bg-image-over-color > .elementor-widget-wrap{
	background-color: <?php echo esc_attr($secondary_color); ?> !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-secondary.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary.cspt-bgimage-yes:not(.cspt-col-stretched-yes) > .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary.cspt-bgimage-yes:not(.cspt-bg-image-over-color) .elementor-widget-wrap .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-secondary .elementor-widget-wrap .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-secondary.cspt-bg-color-over-image:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-secondary.cspt-bgimage-yes > .elementor-widget-wrap:before{
    background-color: <?php echo cspt_hex2rgb($secondary_color, '0.60') ?>;
}

/*====== End --- Row Colum - Light BG Color ======*/

/* --------------------------------------
 * Row Colum - Blackish BG Color
 * ---------------------------------------*/
/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-blackish,
.elementor-section.elementor-top-section.cspt-elementor-bg-color-blackish:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-blackish{
	background-color: <?php echo esc_attr($blackish_color); ?>;
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish:not(.cspt-bgimage-yes) .elementor-widget-wrap > .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish.cspt-bg-image-over-color .elementor-widget-wrap > .cspt-stretched-div,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-blackish.cspt-bg-image-over-color:before,

/*--- Second Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-blackish:not(.cspt-bgimage-yes) > .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-blackish.cspt-bg-image-over-color > .elementor-widget-wrap{
	background-color: <?php echo esc_attr($blackish_color); ?> !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-blackish.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish.cspt-bgimage-yes:not(.cspt-col-stretched-yes) > .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish.cspt-bgimage-yes:not(.cspt-bg-image-over-color) .elementor-widget-wrap .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-blackish .elementor-widget-wrap .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-blackish.cspt-bg-color-over-image:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-blackish.cspt-bgimage-yes > .elementor-widget-wrap:before{
    background-color: <?php echo cspt_hex2rgb($blackish_color, '0.90') ?>;
}
/*====== End --- Row Colum - Blackish BG Color ======*/

/* --------------------------------------
 * Row Colum - White BG Color
 * ---------------------------------------*/
/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-white,
.elementor-section.elementor-top-section.cspt-elementor-bg-color-white:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-white{
	background-color: <?php echo esc_attr($white_color); ?>;
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white:not(.cspt-bgimage-yes) .elementor-widget-wrap > .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white.cspt-bg-image-over-color .elementor-widget-wrap > .cspt-stretched-div,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-white:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) > .elementor-widget-wrap,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-white.cspt-bg-image-over-color:before,

/*--- Second Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-white:not(.cspt-bgimage-yes) > .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-white.cspt-bg-image-over-color > .elementor-widget-wrap{
	background-color: <?php echo esc_attr($white_color); ?> !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-white.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white.cspt-bgimage-yes:not(.cspt-col-stretched-yes) > .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white.cspt-bgimage-yes:not(.cspt-bg-image-over-color) .elementor-widget-wrap .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-white .elementor-widget-wrap .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-white.cspt-bg-color-over-image:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-white.cspt-bgimage-yes > .elementor-widget-wrap:before{
    background-color: <?php echo cspt_hex2rgb($white_color, '0.92') ?>;
}
/*====== End --- Row Colum - White BG Color ======*/

/* --------------------------------------
 * Row Colum - Gradient BG Color
 * ---------------------------------------*/

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:before,

/*--- First RoW BG ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-gradient:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bg-image-over-color .cspt-stretched-div,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bg-image-over-color:not(.cspt-col-stretched-yes) .elementor-widget-wrap,

.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:not(.cspt-col-stretched-yes) .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes .cspt-stretched-div:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient .cspt-bgimage-yes.cspt-stretched-div:before,

/*--- Second RoW BG - with image ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:before,

/*--- Second RoW BG ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-gradient:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-gradient.cspt-bg-image-over-color .elementor-widget-wrap,
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes .elementor-widget-wrap:before{
	background-image: -ms-linear-gradient(right, <?php echo esc_attr($gradient_first); ?> 0%, <?php echo esc_attr($gradient_last); ?> 100%);
	background-image: linear-gradient(to right, <?php echo esc_attr($gradient_first); ?> , <?php echo esc_attr($gradient_last); ?> );
}

/*--- First Colum BG - ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-gradient:not(.cspt-bgimage-yes) .cspt-stretched-div{
	background-image: -ms-linear-gradient(right, <?php echo esc_attr($gradient_first); ?> 0%, <?php echo esc_attr($gradient_last); ?> 100%) !important;
	background-image: linear-gradient(to right, <?php echo esc_attr($gradient_first); ?> , <?php echo esc_attr($gradient_last); ?> ) !important;
}

/*--- First RoW BG - with image ---*/
.elementor-section.elementor-top-section.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:before,

/*--- First Colum BG - with image ---*/
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:not(.cspt-col-stretched-yes) .elementor-widget-wrap:before,
.elementor-column.elementor-top-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes .cspt-stretched-div:before,

/*--- Second RoW BG - with image ---*/
.elementor-section.elementor-inner-section.cspt-elementor-bg-color-gradient.cspt-bgimage-yes:before,

/*--- Second Colum BG - with image ---*/
.elementor-column.elementor-inner-column.cspt-elementor-bg-color-gradient.cspt-bgimage-yes .elementor-widget-wrap:before{
    opacity: 0.5;
}

/*====== End --- Row Colum - Gradient BG Color ======*/

/*========================================== Base Css ==========================================*/

/* --------------------------------------
 * Global Color
 * ---------------------------------------*/

/*=== Global BG Color ===*/
.elementor-progress-bar,
.wp-block-search .wp-block-search__button,
.cspt-team-form button:hover,
.wp-block-tag-cloud a:hover, 
.footer-wrap .widget_tag_cloud a:hover, 

.post.sticky .cspt-blog-classic:after,
.nav-links .page-numbers:hover, 
.nav-links .page-numbers.current,
.search-results .cspt-top-search-form .search-form button,
.search-no-results .search-no-results-content .search-form button,

input[type=submit]:hover,
.reply a:hover,
.cspt-ourhistory .cspt-ourhistory-right:before,

.site-header .cspt-bg-color-globalcolor,
.site-header .cspt-sticky-on.cspt-sticky-bg-color-globalcolor,

.cspt-btn-style-flat .elementor-button,
.cspt-btn-style-flat.cspt-btn-color-globalcolor .elementor-button,

.cspt-bg-color-global,
.cspt-bg-color-globalcolor,
.cspt-footer-section.cspt-bg-color-globalcolor:before,
body .site-footer.cspt-bg-color-blackish .scroll-to-top,
body .scroll-to-top:hover{
    background-color: <?php echo esc_attr($global_color); ?>;
}

.cspt-footer-section.cspt-bg-color-globalcolor.cspt-bg-image-yes:before{
    background-color: <?php echo cspt_hex2rgb($global_color, '0.70') ?>;
}

/*=== Global Text Color ===*/
.cspt-search-results-right .cspt-post-title a:hover,
.cspt-portfolio-single .cspt-portfolio-nav-head,
.cspt-pricing-table-box .cspt-ptable-icon,

.cspt-footer-section.cspt-text-color-globalcolor .widget-title,
.cspt-footer-section.cspt-text-color-globalcolor,
.cspt-footer-section.cspt-text-color-globalcolor a,

.cspt-btn-style-text.cspt-btn-color-globalcolor .elementor-button,

.cspt-globalcolor,
.cspt-skincolor,
.post-navigation .nav-links a:hover{
   	color: <?php echo esc_attr($global_color); ?>;
}

/*=== Global Border Color ===*/
.post.sticky{
	border-color: <?php echo esc_attr($global_color); ?>;
}
.cspt-btn-style-outline .elementor-button{
	border-color: <?php echo esc_attr($global_color); ?>;
	color: <?php echo esc_attr($global_color); ?>;
}
.cspt-pricing-table-featured-col .cspt-pricing-table-box:before{
	border-top: 48px solid <?php echo esc_attr($global_color); ?>;
    border-right: 50px solid <?php echo esc_attr($global_color); ?>;
}

/* --------------------------------------
 * Secondary Color
 * ---------------------------------------*/

/*=== Secondary BG Color ===*/
.elementor-widget-button.cspt-btn-bg-color-secondary .elementor-button,

.cspt-bg-color-secondary,
.cspt-bg-color-secondarycolor,

.cspt-footer-section.cspt-bg-color-secondarycolor:before{
    background-color: <?php echo esc_attr($secondary_color); ?>;
}

.cspt-footer-section.cspt-bg-color-secondarycolor.cspt-bg-image-yes:before{
    background-color: <?php echo cspt_hex2rgb($secondary_color, '0.90') ?>;
}

/*=== Secondary Text Color ===*/
.cspt-footer-section.cspt-text-color-secondarycolor .widget-title,
.cspt-footer-section.cspt-text-color-secondarycolor,
.cspt-footer-section.cspt-text-color-secondarycolor a,

.cspt-btn-style-text.cspt-btn-color-secondary .elementor-button,
.testcolor{
   	color: <?php echo esc_attr($secondary_color); ?>;
}

/*=== Global Border Color ===*/
.testcolor{
	border-color: <?php echo esc_attr($secondary_color); ?>;
}
.cspt-btn-style-outline.cspt-btn-color-secondary .elementor-button{
	border-color: <?php echo esc_attr($secondary_color); ?>;
	color: <?php echo esc_attr($secondary_color); ?>;
}

/* --------------------------------------
 *  Gradient Color
 * ---------------------------------------*/

/*=== Gradient BG Color ===*/
.elementor-widget-button.cspt-btn-color-gradient .elementor-button,
.cspt-bg-color-gradient{
	background-image: -ms-linear-gradient(right, <?php echo esc_attr($gradient_first); ?> 0%, <?php echo esc_attr($gradient_last); ?> 100%);
	background-image: linear-gradient(to right, <?php echo esc_attr($gradient_first); ?> , <?php echo esc_attr($gradient_last); ?> );
}
.cspt-footer-section.cspt-bg-color-gradientcolor:before{
	background-image: -ms-linear-gradient(right, <?php echo esc_attr($gradient_first); ?> 0%, <?php echo esc_attr($gradient_last); ?> 100%) !important;
	background-image: linear-gradient(to right, <?php echo esc_attr($gradient_first); ?> , <?php echo esc_attr($gradient_last); ?> ) !important;
}
.elementor-widget-button.cspt-btn-color-gradient .elementor-button {	
	border-image-slice: 1;
	border-image-source: linear-gradient(to left, <?php echo esc_attr($gradient_first); ?>, <?php echo esc_attr($gradient_last); ?>);
}

/* --------------------------------------
 *  Blackish Color
 * ---------------------------------------*/

 /*=== Blackish BG Color ===*/
button, 
html input[type=button], 
input[type=reset], 
input[type=submit],

.cspt-ptable-btn a,
.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-next, 
.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-prev, 

.cspt-btn-style-flat.cspt-btn-color-globalcolor .elementor-button:hover,
.cspt-btn-style-flat.cspt-btn-color-white .elementor-button:hover,
.cspt-btn-style-flat.cspt-btn-color-blackish .elementor-button,

.cspt-bg-color-blackish,

.cspt-footer-section.cspt-bg-color-blackish:before,

body .scroll-to-top.show:hover{
    background-color: <?php echo esc_attr($blackish_color); ?>;
}

/*=== Blackish Text Color ===*/
.cspt-team-progressbar .elementor-title,
.widget.widget_archive ul > li span,
.nav-links .page-numbers,
.cspt-btn-style-outline.cspt-btn-color-white .elementor-button:hover,
.cspt-pricing-table-featured-col .cspt-ptable-btn a,
.cspt-pricing-table-box .creativesplanet-ptable-price-w,
.cspt-footer-section.cspt-text-color-blackish .widget-title,

.cspt-footer-section.cspt-text-color-blackish a,

.cspt-btn-style-text.cspt-btn-color-blackish .elementor-button,

.cspt-btn-style-flat.cspt-btn-color-light .elementor-button,
.cspt-btn-style-flat.cspt-btn-color-white .elementor-button,

.elementor-widget-progress .elementor-title,
.elementor-progress-percentage,

.cspt-color-blackish,
.cspt-text-color-blackish h1, 
.cspt-text-color-blackish h2, 
.cspt-text-color-blackish h3, 
.cspt-text-color-blackish h4, 
.cspt-text-color-blackish h5, 
.cspt-text-color-blackish h6,
.cspt-blackish{
	color: <?php echo esc_attr($blackish_color); ?>;
}

.cspt-footer-section.cspt-text-color-blackish{
	color: <?php echo cspt_hex2rgb($blackish_bg_color, '0.95') ?>;
}
.cspt-btn-style-outline.cspt-btn-color-blackish .elementor-button{
	border-color: <?php echo esc_attr($blackish_bg_color); ?>;
	color: <?php echo esc_attr($blackish_bg_color); ?>;
}
.cspt-pricing-table-box{
	border-top-color: <?php echo esc_attr($blackish_bg_color); ?>;
}

/* --------------------------------------
 *  Light Color
 * ---------------------------------------*/

.cspt-btn-style-flat.cspt-btn-color-light .elementor-button,
.cspt-bg-color-light,
.cspt-footer-section.cspt-bg-color-light:before{
    background-color: <?php echo esc_attr($light_bg_color); ?>;
}

.cspt-btn-style-text.cspt-btn-color-blackish .elementor-button{
	color: <?php echo esc_attr($light_bg_color); ?>;
}
.cspt-btn-style-outline.cspt-btn-color-light .elementor-button{
	border-color: <?php echo esc_attr($light_bg_color); ?>;
	color: <?php echo esc_attr($light_bg_color); ?>;
}

/* --------------------------------------
 *  White Color
 * ---------------------------------------*/
/*=== Light BG Color ===*/
.cspt-bg-color-white,
.cspt-footer-section.cspt-bg-color-white:before{
    background-color: #fff;
}

.cspt-btn-style-flat.cspt-btn-color-white .elementor-button:hover,
.cspt-color-white,

.cspt-text-color-white .cspt-heading-subheading .cspt-element-title,

.cspt-color-white,
.cspt-text-color-white h1, 
.cspt-text-color-white h2, 
.cspt-text-color-white h3, 
.cspt-text-color-white h4, 
.cspt-text-color-white h5, 
.cspt-text-color-white h6,
.cspt-white{
	color: <?php echo esc_attr($white_color); ?>;
}

/*========================================== End Base Css ==========================================*/

/*==========================================THEME SPECIAL===========================================*/

/* --------------------------------------
 * Global color 
 * ---------------------------------------*/
.cspt-footer-widget .cspt-footer-social-globalcolor .cspt-social-links li a:hover,
.cspt-btn-style-outline .elementor-button:hover,
.cspt-team-style-4 .creativesplanet-box-team-position,
.cspt-search-results .cspt-read-more-link a:hover,
.cspt-blog-meta-top .cspt-meta,
.cspt-subheading-skincolor .cspt-heading-subheading .cspt-element-subtitle,
.cspt-tab-content .cspt-tab-content-title i, 
.cspt-tabs .cspt-tabs-heading li i,
.widget_calendar table td#today,
.cspt-portfolio-style-2 .cspt-port-cat a,
.cspt-element-service-style-2.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-prev:hover,
.cspt-element-service-style-2.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-next,
.cspt-main-form.cspt-form-style-4 .input-button .wpcf7-form-control,
.cspt-ourhistory .label,
.cspt-accordion-style1.elementor-widget-accordion .elementor-accordion .elementor-tab-title .elementor-accordion-title span,
.cspt-ihbox-style-13 .cspt-ihbox-icon-wrapper,
.cspt-testimonial-style-1 .cspt-designation,
.cspt-ihbox-style-11 .cspt-ihbox-icon-wrapper,
.cspt-ihbox-style-10 .cspt-ihbox-icon-wrapper,
.cspt-blog-meta.cspt-blog-meta-top a,
.cspt-skincolor-icon.cspt-contact-info li i,
.cspt-skincolor-icon.elementor-widget .elementor-icon-list-icon i,
.cspt-blog-classic blockquote:after,
.cspt-blog-classic-inner .cspt-read-more-link a:hover,
.cspt-blog-meta-top .cspt-meta a:hover,
.karon_recent_posts_widget .cspt-rpw-content .cspt-rpw-date a,
.cspt-header-style-1 .cspt-header-button:hover a .cspt-header-button-text-2,
.cspt-header-style-4 .cspt-header-button:hover a .cspt-header-button-text-2,
.cspt-testimonial-style-4 .cspt-designation,
.cspt-subheading-skincolor .cspt-heading-subheading .cspt-element-subtitle,
.cspt-testimonial-style-4 .creativesplanet-box-star-ratings,
.cspt-service-style-4 .creativesplanet-box-content .cspt-service-btn a:hover,
.cspt-testimonial-style-4 .creativesplanet-box-content:after,
.cspt-subheading-skincolor .cspt-heading-subheading .cspt-element-subtitle,
.cspt-testimonial-style-3 .cspt-designation,
.cspt-blog-style-4 .creativesplanet-box-content .creativesplanet-box-desc .cspt-meta-category i,
.cspt-blog-style-4 .creativesplanet-box-content .creativesplanet-box-desc .cspt-meta-author-wrapper i,
.cspt-service-style-4 .creativesplanet-box-content .cspt-service-icon-wrapper,
.cspt-footer-section.cspt-text-color-white a:hover,
.creativesplanet-ele-fid-style-4 .cspt-sbox-icon-wrapper,
.cspt-service-style-1 .cspt-service-title a:hover,
.cspt-static-box-style-1 .cspt-contentbox .cspt-karon-icon,
.creativesplanet-ele-fid-style-3 .cspt-sbox-icon-wrapper,
.site-footer .karon_recent_posts_widget .cspt-rpw-content .cspt-rpw-date a,
.cspt-ihbox-style-6 .cspt-ihbox-icon-wrapper,
.elementor-heading-title.elementor-size-default em,
.cspt-ihbox-style-5 .cspt-ihbox-icon i,
.creativesplanet-ele-ptable-style-1 .cspt-ptable-line i,
.cspt-team-single-style-1 .cspt-team-designation,
.creativesplanet-ele-fid-style-6 .cspt-fid-inner,
.creativesplanet-ele-fid-style-6 .cspt-fid-inner .cspt-fid-sub,
.cspt-team-style-2 .creativesplanet-box-team-position,
.cspt-team-style-1 .creativesplanet-box-team-position,
.cspt-testimonial-style-1 .creativesplanet-box-star-ratings,
.cspt-testimonial-style-2 .creativesplanet-box-star-ratings,
.cspt-blog-style-1 .cspt-read-more-link a:hover span:after,
.cspt-blog-style-1 .cspt-read-more-link a:hover,
.cspt-element-blog-style-1 .multi-columns-row .cspt-blog-ele:nth-child(even) .cspt-blog-style-1 .cspt-meta-category a,
.cspt-service-style-1 .cspt-service-cat a,
.cspt-service-style-2 .cspt-service-cat a,
.cspt-service-style-3 .cspt-service-title a:hover,
.cspt-service-style-3 .cspt-service-icon-wrapper,
.creativesplanet-ele-fid-style-2 .cspt-fid-inner,
.creativesplanet-ele-fid-style-4 .cspt-sbox-icon-wrapper,
.elementor-widget .elementor-icon-list-icon i,
.cspt-ihbox-style-1 .cspt-ihbox-icon-wrapper i,
.cspt-ihbox-style-2 .cspt-ihbox-icon-wrapper{
	color: <?php echo esc_attr($global_color); ?>;
}

.cspt-bg-color-blackish .cspt-element-testimonial-style-1.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-next:hover, 
.cspt-bg-color-blackish .cspt-element-testimonial-style-1.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-prev:hover{
	color: <?php echo esc_attr($global_color); ?> !important;
}

.cspt-footer-widget .cspt-footer-social-globalcolor .cspt-social-links li a,
.cspt-btn-style-outline.cspt-btn-color-globalcolor .elementor-button:hover,
.cspt-tabs .cspt-tab-content-inner ul:after,
.cspt-tabs .cspt-tab-content-inner ul:before,
.cspt-tabs .cspt-tabs-heading li.cspt-tab-li-active,
.creativesplanet-ele-fid-style-3 .cspt-fld-contents h4 .cspt-number-rotate:after,
.cspt-header-slider-yes.site-header.cspt-header-style-2,
.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-featured-col .cspt-pricing-table-box .creativesplanet-ptable-price-head,
.cspt-form-style-3 h3,
.cspt-ihbox-style-9 .cspt-ihbox-box:after,
body .scroll-to-top,
.cspt-ihbox-style-13 .cspt-ihbox-box-number,
.cspt-element-service-style-2 .cstp-sevice-button a,
.cspt-element-testimonial-style-1.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot.active,
.creativesplanet-ele-fid-style-4 .cspt-fld-contents h4 .cspt-number-rotate:after,
.cspt-element-service-style-2 .cspt-service-2-carousel-area .cspt-stretched,
.creativesplanet-ele-fid-style-5 .cspt-fld-contents h4 .cspt-number-rotate:after,
.cspt-btn-style-flat.cspt-btn-color-blackish .elementor-button:hover,
.cspt-ihbox-style-12 .cspt-ihbox-icon-wrapper,
.creativesplanet-element-viewtype-carousel[data-nav="above"] .cspt-carousel-navs a:hover,
.cspt-text-color-white .creativesplanet-element-viewtype-carousel[data-nav="above"] .cspt-carousel-navs a.cspt-carousel-next,
.cspt-text-color-white .creativesplanet-element-viewtype-carousel[data-nav="above"] .cspt-carousel-navs a:hover,
.creativesplanet-ele-fid-style-7 .cspt-fld-contents h4 .cspt-number-rotate:after,
.creativesplanet-sidebar .widget.widget_product_search,
.creativesplanet-sidebar .widget.widget_search,
.cspt-tabs .cspt-tab-content-inner ul li:after,
body .cspt-blog-meta-top span+span:before,
.cspt-ptable-btn a:hover,
.cspt-text-color-white .creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-next:hover, 
.cspt-text-color-white .creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button.owl-prev:hover,
.creativesplanet-element-viewtype-carousel .owl-carousel .owl-nav button:hover, 
.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-featured-col .cspt-pricing-table-box .cspt-ptable-btn a:hover,
.elementor-widget-icon-list .elementor-widget-container .elementor-icon-list-items:after,
.elementor-widget-icon-list .elementor-widget-container .elementor-icon-list-items:before,
.cspt-contact-social-area ul a,
.single-service-contact .cspt-ihbox-icon,
.cspt-team-single .cspt-team-social-links a,
.cspt-blog-classic .cspt-meta-date-top, 
.cspt-vertical-sep.elementor-inner-column:after,
.cspt-vertical-sep.elementor-inner-column:before,
.cspt-bottom-part,
.cspt-vertical-icon.elementor-view-stacked .elementor-icon,
.cspt-ihbox-style-8 .cspt-ihbox-box .cspt-ihbox-icon .cspt-ihbox-icon-wrapper:after,
.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot.active,
.cspt-element-testimonial-style-3.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot.active,
.cspt-element-portfolio-style-1.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot.active,
.elementor-accordion .elementor-tab-title.elementor-active,
.cspt-team-style-1 .creativesplanet-team-image-box:before,
.single-cspt-service .creativesplanet-sidebar .widget ul > li.cspt-post-active a,
.single-cspt-service .creativesplanet-sidebar .widget ul > li:hover a,
.elementor-accordion .elementor-tab-title.elementor-active,
.cspt-main-form.cspt-form-style-3 .input-button button:hover,
.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-box .cspt-ptable-btn a,
.cspt-footer-widget .mc4wp-form .cspt-footer-newslatter button[type=submit],
.cspt-footer-widget .cspt-social-links li a:hover,
.site-footer .widget-title:after,
.cspt-team-style-1 .creativesplanet-team-image-box:before,
.creativesplanet-sidebar .widget_tag_cloud ul li a:hover,
.cspt-testimonial-style-1 .creativesplanet-box-img:after,
.cspt-testimonial-style-2 .creativesplanet-box-inner .cspt-featured-wrapper:after,
.cspt-blog-style-1 .cspt-meta-category,
.elementor-widget-progress .elementor-progress-wrapper .elementor-progress-bar,
.elementor-progress-wrapper .elementor-progress-text:after,
.cspt-main-form.cspt-form-style-1 .input-button button:hover,
.cspt-element-blog-style-1 .multi-columns-row .cspt-blog-style-1.cspt-ele-blog:nth-child(even),
.cspt-blog-style-4 .creativesplanet-box-content .cspt-meta-date-wrapper .cspt-meta-date,
.cspt-blog-style-2 .cspt-meta-category a,
.cspt-blog-style-3 .cspt-meta-category a,
.cspt-portfolio-style-1 .creativesplanet-icon-box,
.cspt-portfolio-style-1 .creativesplanet-icon-box a,
.cspt-portfolio-style-2:hover .cspt-content-wrapper,

.cspt-service-style-1 .cspt-service-icon-wrapper,
.cspt-service-style-2 .cspt-service-icon-wrapper,
.widget .service-offer .content-box .mail-box a,
.cspt-ihbox-style-3,
.cspt-ihbox-style-4 .cspt-ihbox-icon-wrapper,
.widget .widget-download,
.cspt-team-style-1 .creativesplanet-box-social-links i.cspt-base-icon-share{
	background-color: <?php echo esc_attr($global_color); ?>;
}
.cspt-portfolio-style-1 .creativesplanet-post-content:after{
	background-color: <?php echo cspt_hex2rgb($global_color, '0.90') ?>;
}
.cspt-team-style-2 .creativesplanet-team-image-box:before{
	background-color: <?php echo cspt_hex2rgb($global_color, '0.96') ?>;
}
.creativesplanet-sidebar .widget .widget-title:after{
	background: linear-gradient(to right,<?php echo esc_attr($global_color); ?> 0%,<?php echo esc_attr($global_color); ?> 66%,rgba(255,255,255,0) 66%,rgba(255,255,255,0) 71%,<?php echo cspt_hex2rgb($global_color, '0.5') ?> 71%);
}
.cspt-testimonial-style-1 .creativesplanet-testimonial-inner{
	border-top-color: <?php echo esc_attr($global_color); ?>;
}
.cspt-heading-subheading .cspt-element-heading{
	border-bottom-color: <?php echo esc_attr($global_color); ?>;
}
.cspt-tabs .cspt-tabs-heading li.cspt-tab-li-active:after,
.creativesplanet-ele-fid-style-3::before{
	border-color: <?php echo esc_attr($global_color); ?> transparent transparent transparent;
}
.cspt-author-box{
	border-left-color: <?php echo esc_attr($global_color); ?>;
}
.cspt-portfolio-single-style-1 .cspt-portfolio-lines-wrapper{
	border-top-color: <?php echo esc_attr($global_color); ?>;
}

/* --------------------------------------
 * Secondary color
 * ---------------------------------------*/

.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-featured-col .cspt-pricing-table-box .cspt-ptable-btn a,
.cspt-main-form.cspt-form-style-4 .input-button .wpcf7-form-control:hover,
.cspt-element-testimonial-style-1.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot,
.widget.widget_search .search-form button,
.widget .service-offer .content-box:after,
.widget .service-offer .content-box:before,
.cspt-testimonial-style-1 .creativesplanet-box-title:after,
.cspt-ihbox-style-1 .cspt-ihbox-box-number,
.cspt-blog-style-4 .creativesplanet-box-content .creativesplanet-box-desc .cspt-meta-category:before,
.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-box .cspt-ptable-btn a:hover,
.cspt-portfolio-style-2 .cspt-link-icon,
.cspt-service-style-1:hover .cspt-service-icon-wrapper,
.cspt-service-style-2:hover .cspt-service-icon-wrapper,
.cspt-element-testimonial-style-3.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot,
.cspt-element-portfolio-style-1.creativesplanet-element-viewtype-carousel .owl-carousel button.owl-dot,
.cspt-secondary-color{
	background-color: <?php echo esc_attr($secondary_color); ?>;
}

.cspt-blog-style-3 .cspt-post-footer .cspt-meta-date,
.cspt-blog-style-2 .cspt-post-footer .cspt-meta-author-wrapper, 
.cspt-blog-style-2 .cspt-post-footer .cspt-meta-date,
.cspt-tabs .cspt-tabs-heading li span,
.creativesplanet-ele-fid-style-7 .cspt-fid-inner,
.elementor-heading-title.elementor-size-default span,
.cspt-accordion-style1 .elementor-accordion .elementor-tab-title.elementor-active .elementor-accordion-icon,
.cspt-service-style-3:hover .cspt-service-title a,
.cspt-main-form.cspt-form-style-2 .wpcf7-submit:hover,
.cspt-testimonial-style-3 .creativesplanet-box-star-ratings i,
.cspt-footer-widget .mc4wp-form .cspt-footer-newslatter button:hover[type=submit],
.creativesplanet-ele-ptable-style-1 .creativesplanet-ptable-price-w *,
.cspt-testimonial-style-1 blockquote,
.cspt-testimonial-style-1 .creativesplanet-box-title,
.cspt-element-blog-style-1 .multi-columns-row .cspt-blog-style-1.cspt-ele-blog:nth-child(even) .cspt-meta-category a,
.creativesplanet-ele-fid-style-1 .cspt-circle-number,
.creativesplanet-ele-fid-style-1 .cspt-fid-title,
.cspt-ihbox-style-1 .cspt-ihbox-icon-wrapper,
.cspt-testimonial-style-1 .creativesplanet-box-author,
.cspt-testimonial-style-1:after,
.cspt-blog-style-1 .cspt-read-more-link a span:after{
	color: <?php echo esc_attr($secondary_color); ?>;
}
.test-color{
	border-color: <?php echo esc_attr($secondary_color); ?>;
}
.cspt-blog-style-1 .post-item{
	border-bottom-color: <?php echo esc_attr($secondary_color); ?>;
}

/* --------------------------------------
 * Blackish color
 * ---------------------------------------*/
/* Karon Special */

.cspt-elementor-bg-color-secondary .cspt-btn-style-flat.cspt-btn-color-globalcolor .elementor-button:hover,
.cspt-search-results .cspt-read-more-link a,
.woocommerce table.shop_table th,
.cspt-team-single-style-1 .cspt-single-team-info li label,
.widget_categories ul li span,
.site-content .widget.widget_archive ul > li span,
.cspt-blog-meta-bottom .cspt-meta-tags .cspt-meta-title,
.cspt-comment-content .cspt-comment-author,
.cspt-text-color-white .creativesplanet-element-viewtype-carousel[data-nav="above"] .cspt-carousel-navs a.cspt-carousel-next:hover,
.cspt-text-color-white .creativesplanet-element-viewtype-carousel[data-nav="above"] .cspt-carousel-navs a,
.site-footer.cspt-text-color-white .widget_tag_cloud a,
.creativesplanet-ele-ptable-style-2 .cspt-pricing-table-featured-col .cspt-pricing-table-box .creativesplanet-ptable-heading,
.creativesplanet-ele-ptable-style-2 .cspt-pricing-table-featured-col .cspt-pricing-table-box .cspt-ptable-icon,
.cspt-blog-classic-inner .cspt-read-more-link a,

.search-form .search-submit:after,

.cspt-bottom-part.elementor-widget-heading .elementor-heading-title span,

.elementor-widget-accordion .elementor-accordion-icon, 
.elementor-widget-accordion .elementor-accordion-title,

.cspt-blackish-title .cspt-heading-subheading h2.cspt-element-title,
.cspt-blackish .cspt-heading-subheading h4.cspt-element-subtitle,
.cspt-vertical-text .elementor-heading-title span{
	color: <?php echo esc_attr($blackish_color); ?>;
}

.widget.widget_product_search .woocommerce-product-search button,
.cspt-element-service-style-2 .cstp-sevice-button a:hover,
.cspt-carousel-navs a,
.cspt-heaing-style-1.cspt-blackish .cspt-heading-subheading:before,
.cspt-heaing-style-1.cspt-blackish .cspt-heading-subheading:after,

.cspt-contact-social-area ul a:hover,
.reply a,
.cspt-single-project-details-list,
.test-bg-color{
	background-color: <?php echo esc_attr($blackish_color); ?>;
} 
.single-service-contact:after{
	background-color: <?php echo cspt_hex2rgb($blackish_color, '0.85') ?>;
}

.cspt-heaing-style-1.cspt-blackish .cspt-heading-subheading{
	border-left-color:  <?php echo cspt_hex2rgb($blackish_color, '0.15') ?>;
}
.creativesplanet-ele-ptable-style-2 .cspt-pricing-table-featured-col .cspt-pricing-table-box:before {
    border-top: 48px solid <?php echo esc_attr($blackish_color); ?>;
    border-right: 48px solid <?php echo esc_attr($blackish_color); ?>;
}

/* --------------------------------------
 * Light color
 * ---------------------------------------*/
.cspt-ihbox-style-11 .cspt-ihbox-icon-wrapper,
.cspt-ihbox-style-6 .cspt-ihbox-box,
.cspt-team-left-inner,
.cspt-blog-style-2 .creativesplanet-box-content,
.cspt-blog-style-1,
.creativesplanet-ele-ptable-style-1 .cspt-pricing-table-box .creativesplanet-ptable-price-head,

.cspt-portfolio-single-style-1 .portfolio-details-content,
input[type="number"], input[type="text"], input[type="email"], input[type="password"], input[type="tel"], input[type="url"], input[type="search"], textarea,
.creativesplanet-sidebar .widget,
.test-bg-color{
	background-color: <?php echo esc_attr($light_bg_color); ?>;
}

.test-bg-color{
	color: <?php echo esc_attr($light_bg_color); ?>;
}

/* --------------------------------------
 * Gradient color 
 * ---------------------------------------*/
.testbg{
	background-image: -ms-linear-gradient(right, <?php echo esc_attr($gradient_first); ?> 0%, <?php echo esc_attr($gradient_last); ?> 100%);
	background-image: linear-gradient(to right, <?php echo esc_attr($gradient_first); ?> , <?php echo esc_attr($gradient_last); ?> );
}

/*====================================  woocommerce  ====================================*/
.woocommerce-info, .woocommerce-message{
	border-top-color: <?php echo esc_attr($global_color); ?>;
}
.woocommerce-info::before,
.woocommerce ul.cart_list li ins,
.woocommerce ul.product_list_widget li ins{
	color: <?php echo esc_attr($global_color); ?>;
}
.single-product .entry-summary .product_meta .posted_in, 
.single-product .entry-summary .product_meta .sku_wrapper{
	color: <?php echo esc_attr($blackish_bg_color); ?>;
}
.woocommerce-product-search [type=submit],

.woocommerce-form-coupon button[type=submit]:hover, 
.woocommerce #payment #place_order, 
.woocommerce-page #payment #place_order,
.woocommerce #review_form #respond .form-submit input,
.woocommerce .woocommerce-error .button:hover, 
.woocommerce .woocommerce-info .button:hover, 
.woocommerce .woocommerce-message .button:hover, 
.woocommerce-page .woocommerce-error .button:hover, 
.woocommerce-page .woocommerce-info .button:hover, 
.woocommerce-page .woocommerce-message .button:hover,
.woocommerce nav.woocommerce-pagination ul li a:hover, 
.woocommerce nav.woocommerce-pagination ul li span.current,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-range,
.woocommerce .widget_shopping_cart .buttons a:not(.wcppec-cart-widget-button), 
.woocommerce.widget_shopping_cart .buttons a:not(.wcppec-cart-widget-button),
.woocommerce .widget_price_filter .price_slider_amount .button,
.woocommerce .cart .button, 
.woocommerce .cart input.button,
#add_payment_method .wc-proceed-to-checkout a.checkout-button, 
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button, 
.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button,
.woocommerce div.product form.cart .button,
.woocommerce div.product .woocommerce-tabs ul.tabs li a,
.woocommerce ul.products li.product .button{
	background-color: <?php echo esc_attr($global_color); ?>;
}

.widget_product_categories ul li .count,
.woocommerce-form-coupon button[type=submit],
.woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content,
.woocommerce .widget_price_filter .price_slider_amount .button:hover,
.woocommerce #review_form #respond .form-submit input:hover,
.woocommerce .woocommerce-error .button, 
.woocommerce .woocommerce-info .button, 
.woocommerce .woocommerce-message .button, 
.woocommerce-page .woocommerce-error .button, 
.woocommerce-page .woocommerce-info .button, 
.woocommerce-page .woocommerce-message .button,
.woocommerce .woocommerce-error .button:hover, 
.woocommerce .woocommerce-info .button:hover, 
.woocommerce .woocommerce-message .button:hover, 
.woocommerce-page .woocommerce-error .button:hover, 
.woocommerce-page .woocommerce-info .button:hover, 
.woocommerce-page .woocommerce-message .button:hover,
.woocommerce .cart .button:hover, 
.woocommerce .cart input.button:hover, 
#add_payment_method .wc-proceed-to-checkout a.checkout-button:hover, 
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover, 
.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:hover, 
.woocommerce div.product form.cart .button:hover,  
.woocommerce ul.products li.product .button:hover{
	background-color: <?php echo esc_attr($blackish_bg_color); ?>;
}

.woocommerce-info,
.woocommerce-message {
    border-top-color: <?php echo esc_attr($global_color); ?>;
}

/*====================================  End Dynamic color  ====================================*/

/* * * * *  MENU AND BREAKPOINT CSS  * * * * * */
/*====================================  Max Width for dynamic breakpoint  ====================================*/
@media (max-width: <?php echo esc_attr($responsive_breakpoint); ?>px){

	.cspt-header-style-3 .cspt-header-top-area > .container > .d-flex,
	.cspt-header-top-area > .container{
		position: relative;
	}

	.cspt-header-info-inner,
	.something{
		display: none;
	}
	.navbar-expand-lg .navbar-nav{
		-ms-flex-direction: unset !important;
		flex-direction: unset !important;
	}
	.cspt-header-menu-area-inner,
	.cspt-navbar{
	    display: block !important;
	}
	.nav-menu-toggle{
	    display: block;
	    position: absolute;
	    right: 0px;
	    top: 50%;
	    -webkit-transform: translateY(-50%);
	    -ms-transform: translateY(-50%);
	    transform: translateY(-50%);
	    background-color: transparent;
	    padding: 0;
	    font-size: 35px;
	    line-height: 35px;
	    color: #2c2c2c;
	    width: 40px;
	}
	.cspt-navbar > div{
		background-color: #fff;
	}
	.sub-menu{
		display: none;
	}
	.cspt-header-menu-area-wrapper{
		min-height: auto !important;
	}
	.closepanel{
		position: absolute;
		z-index: 99;
		right: 35px;
		top: 25px;
		display: block;
		width: 30px;
		height: 30px;
		line-height: 30px;		
		border-radius: 50%;
		text-align: center;
		cursor: pointer;
		font-size: 35px;
		color: #fff;
	}
	.admin-bar .closepanel{
		top: 45px;
	}

	/*=== Responsive menu ===*/
	.cspt-navbar > div {
	    background-color: #fff;
	    position: fixed;
		top: 0;
		right: 0;
	    z-index: 1000;
	    width: 300px;
	    height: 100%;
	    padding: 0;
	    display: block;
	    background-color: #222;
	    -webkit-transition: transform 0.4s ease;
	    transition: transform 0.4s ease;
	    -webkit-transform: translateX(400px);
	    -ms-transform: translateX(400px);
	    transform: translateX(400px);
	    -webkit-backface-visibility: hidden;
	    backface-visibility: hidden;
	    visibility: hidden;
	    opacity: 0
	}
	.cspt-navbar > div.active {
	    -webkit-transform: translateX(0);
	    -ms-transform: translateX(0);
	    transform: translateX(0);
	    visibility: visible;
	    opacity: 1;
		overflow-y: scroll;
	}
	.cspt-navbar > div > ul{
		padding: 90px 0;
	}
	.cspt-navbar > div > ul li a {
	    color: #fff !important;
	    padding: 15px 25px;
	    height: auto;
	    display: inline-block;
	}
	.cspt-navbar > div > ul ul {
	    padding-left: 1em;
	    overflow: hidden;
	    display: none;
	}
	ul .sub-menu.show,
	ul .children.show {
	    display: block;
	}
	.cspt-navbar li{
		position: relative;
	}
	.cspt-navbar ul.menu > li{
		border-bottom: 1px solid rgba(204, 204, 204, 0.10);
	}
	.sub-menu-toggle{
	    display: block;
	    position: absolute;
	    right: 25px;
	    top: 15px;
	    cursor: pointer;
	    color: rgba(255, 255, 255, 0.80);
	}
	.cspt-navbar ul ul{
		background-color: transparent !important;
	}
	.cspt-header-style-2 .cspt-header-content{
		margin: 0 30px;
		position: relative;
	}
	.cspt-header-style-2 .nav-menu-toggle{
	    color: #fff;
	}

	/*=== Reset Sticky ===*/
	.cspt-header-style-4 .cspt-header-wrapper.cspt-sticky-on,
	.cspt-header-style-1 .cspt-header-wrapper.cspt-sticky-on{
		position: static !important;
		width: auto !important;
	}
	.cspt-header-style-4 .cspt-header-wrapper > .container > .d-flex,
	.cspt-header-style-1 .cspt-header-wrapper > .container > .d-flex{
		position: relative;
	}
	.cspt-header-style-4 .cspt-header-search-btn,
	.cspt-header-style-1 .cspt-header-search-btn {	
	    position: absolute;
	    right: 60px;
	}
	.cspt-header-style-4 .cspt-right-box,
	.cspt-header-style-3 .cspt-right-box,
	.cspt-header-style-2 .cspt-right-box,
	.cspt-header-style-1 .cspt-right-box{
		display: none;
	}
	.cspt-mobile-search{
		display: block;
	}
	.cspt-mobile-search .cspt-header-search-btn{
		display: block;
		position: absolute;
		right: 60px;
		top: 50%;
		-webkit-transform: translateY(-50%);
		-ms-transform: translateY(-50%);
		transform: translateY(-50%);
	}
	.cspt-header-style-4 .container{
		padding: 0;
	}
	.cspt-header-style-4 .cspt-header-content{
		margin: 0 15px;
	}

	/*=== Responsive Logo ===*/
	.cspt-responsive-logo-yes .cspt-sticky-logo,
	.cspt-responsive-logo-yes .cspt-main-logo{
		display: none;
	}
	.cspt-responsive-logo-yes .cspt-responsive-logo{
		display: inline-block;
	}
	/*=== Responsive header background color ===*/
	.cspt-responsive-header-bgcolor-globalcolor .cspt-header-wrapper{
		background-color: <?php echo esc_attr($global_color); ?> !important;
	}
	.cspt-responsive-header-bgcolor-white .cspt-header-wrapper{
		background-color: #fff !important;
	}
	.cspt-responsive-header-bgcolor-blackish .cspt-header-wrapper{
		background-color: #222 !important;
	}
	.cspt-cart-wrapper{
		display: none !important
	}
}
/*====================================  End Max Break Point  ====================================*/
/*====================================  Min Width for dynamic breakpoint  ====================================*/
@media (min-width: <?php echo esc_attr($responsive_breakpoint); ?>px) {
	.cspt-responsive-logo{
		display: none;
	}
	.nav-menu-toggle,
	.something{
		display: none;
	}
	.cspt-sticky-on .site-title img.cspt-main-logo,
	.site-title img.cspt-sticky-logo{
		max-height: <?php echo esc_attr($sticky_logo_height); ?>px;
	}
	.cspt-sticky-on.cspt-header-wrapper{
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
	}
	.cspt-navbar > div > ul > li,
	.cspt-navbar > div > ul > li > a{
	    line-height: <?php echo esc_attr($header_height); ?>px !important;
	    height: <?php echo esc_attr($header_height); ?>px;
	}
	.cspt-sticky-on .cspt-navbar > div > ul > li,
	.cspt-sticky-on .cspt-navbar > div > ul > li > a,
	.cspt-sticky-on .site-title {
	    line-height: <?php echo esc_attr($sticky_header_height); ?>px !important;
	    height: <?php echo esc_attr($sticky_header_height); ?>px;
	}
	.cspt-navbar ul > li > ul > li.current-menu-item > a,
	.cspt-navbar ul > li > ul li.current_page_item > a,
	.cspt-navbar ul > li > ul li.current_page_ancestor > a,
	.cspt-navbar > div > ul > li:hover > a,
	.cspt-navbar > div > ul > li.current_page_item > a,
	.cspt-navbar > div > ul > li.current-menu-parent > a {
	   color: <?php echo esc_attr($global_color); ?>;
	}
	.cspt-navbar ul > li > ul li.current_page_item > a:before,
	.cspt-navbar ul > li > ul li.current_page_ancestor > a:before,
	.cspt-navbar ul > li > ul li.current_page_parent > a:before{
		 background-color: <?php echo esc_attr($global_color); ?>;
	}
	.cspt-navbar ul > li > ul li:hover > a {
	   color: #ffffff !important;
	}
	.cspt-navbar > div > ul {
	   position: relative;
	   z-index: 597;
	}
	.cspt-navbar > div > ul > li {
	   float: left;
	   min-height: 1px;
	   vertical-align: middle;
	   position: relative;
	}
	.cspt-navbar > div > ul ul {
	   visibility: hidden;
	   position: absolute;
	   top: 100%;
	   left: 0;
	   z-index: 598;
	}
	.cspt-navbar ul > li:hover > ul{
		z-index: 600;
	}
	.cspt-navbar > div > ul li ul.cspt-nav-left{
	    left: inherit;
	    right: 0;		
	}
	.cspt-navbar > div > ul li ul ul.cspt-nav-left{
	    left: -100%;
	    right: 0;
	}	
	.cspt-navbar > div > ul ul li {
	   float: none;
	}
	.cspt-navbar > div > ul ul ul {
	   top: 0;
	   left: 100%;
	   width: 190px;
	}
	.cspt-navbar > div > ul ul {
	  margin-top: 0;
	}
	.cspt-navbar > div > ul ul li {
	    font-weight: normal;
	}
	.cspt-navbar a {
	    display: block;
	    line-height: 1em;
	    text-decoration: none;
	}
	.cspt-navbar > div > ul ul li:hover > a{
		background-color: <?php echo esc_attr($global_color); ?>;
	}
	/* Custom CSS Styles */
	.cspt-navbar > ul {
	  *display: inline-block;
	}
	.cspt-navbar:after,
	.cspt-navbar ul:after {
	   content: '';
	   display: block;
	   clear: both;
	}
	.cspt-navbar ul {
	   text-transform: uppercase;
	}
	.cspt-navbar ul ul {
		min-width: 270px;
		opacity: 0;
		visibility: hidden;
		-webkit-transition: all 0.3s linear 0s;
		transition: all 0.3s linear 0s;
		box-shadow: 0px 10px 40px rgba(0,0,0,0.20);
		border-top: 3px solid <?php echo esc_attr($global_color); ?>;
	}
	.cspt-navbar ul > li:hover > ul {
	    visibility: visible;
	    opacity: 1;
	}
	.cspt-navbar ul > li > ul > li > a{
	   padding: 15px 30px;
	}
	.cspt-navbar ul > li > ul > li:hover > a{
		padding-left: 40px;
	}
	.cspt-navbar ul > li > ul > li > a:before {
	    position: absolute;
	    content: '';
	    left: 18px;
	    top: 24px;
	    width: 0px;
	    height: 2px;
	    background-color: transparent;
	    -webkit-transition: all .500s ease-in-out;
	    transition: all .500s ease-in-out;
	}
	.cspt-navbar ul > li > ul > li:hover >a:before{
		background-color: rgba(255, 255, 255, 0.50);
		width: 10px;
	}
	.cspt-navbar ul ul a {
	   border-bottom: 1px solid rgba(0, 0, 0, 0.10);
	   border-top: 0 none;
	   line-height: 150%;
	   padding: 16px 20px;
	}
	.cspt-navbar ul ul ul {
	   border-top: 0 none;
	}
	.cspt-navbar ul ul li {
	   position: relative;
	}
	.cspt-navbar ul li.last ul {
	    left: auto;
	    right: 0;
	}
	.cspt-navbar ul li.last ul ul {
	   left: auto;
	   right: 99.5%;
	}
	.cspt-navbar div > ul > li > a{
	    margin: 0 20px;
	}

	/*=== Dropdown Menu ( Globalcolor ) ===*/
	.cspt-navbar.cspt-dropdown-active-color-globalcolor ul > li > ul > li.current-menu-item > a, 
	.cspt-navbar.cspt-dropdown-active-color-globalcolor ul > li > ul li.current_page_item > a, 
	.cspt-navbar.cspt-dropdown-active-color-globalcolor ul > li > ul li.current_page_ancestor > a,

	/* Main Menu ( Globalcolor )*/
	.cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li:hover > a, 
	.cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current_page_item > a, 
	.cspt-navbar.cspt-main-active-color-globalcolor > div > ul >li.current-menu-parent > a{
	    color: <?php echo esc_attr($global_color); ?>;
	}

	/* Dropdown Menu ( Secondarycolor )*/
	.cspt-navbar.cspt-dropdown-active-color-secondarycolor ul > li > ul > li.current-menu-item > a, 
	.cspt-navbar.cspt-dropdown-active-color-secondarycolor ul > li > ul li.current_page_item > a, 
	.cspt-navbar.cspt-dropdown-active-color-secondarycolor ul > li > ul li.current_page_ancestor > a,

	/* Main Menu ( Secondarycolor )*/
	.cspt-navbar.cspt-main-active-color-secondarycolor > div > ul > li:hover > a, 
	.cspt-navbar.cspt-main-active-color-secondarycolor > div > ul > li.current_page_item > a, 
	.cspt-navbar.cspt-main-active-color-secondarycolor > div > ul >li.current-menu-parent > a{
	    color: <?php echo esc_attr($secondary_color); ?>;
	}
	.cspt-header-menu-area .cspt-navbar div > ul > li,
	.cspt-header-menu-area .cspt-navbar div > ul > li > a,
	.cspt-header-menu-area{
		height: 70px;
		line-height: 70px !important;
	}
	.cspt-header-menu-area.cspt-sticky-on .cspt-navbar div > ul > li,
	.cspt-header-menu-area.cspt-sticky-on .cspt-navbar div > ul > li > a,
	.cspt-header-menu-area.cspt-sticky-on{
		height: 70px;
		line-height: 70px !important;
	}
	.cspt-header-menu-area{
	    position: relative;
	    z-index: 9;
	}

	/*=== cspt-header-style-1 ===*/
	.cspt-header-style-1 .cspt-navbar div > ul > li > a{
		margin: 0 15px;
	}
	.cspt-header-style-1 .cspt-navbar.cspt-bigger-menu div > ul > li > a{
		margin: 0 8px;
	}
	.cspt-header-style-1 .cspt-right-box {
	    margin-left: 10px;
	    display: flex;
	}
	.cspt-header-style-1 .cspt-logo-menuarea {
		display: -ms-flexbox!important;
		display: flex!important;
		display: -ms-flexbox!important;
		display: flex!important;
		-webkit-flex: 1;
		-ms-flex: 1;
		flex: 1;
		-webkit-box-pack: justify!important;
		-ms-flex-pack: justify!important;
		justify-content: space-between!important;
	}
	.cspt-header-style-1 .cspt-header-button {
		line-height: normal;
	}
	.cspt-header-style-1 .cspt-header-button a{
		color: <?php echo esc_attr($blackish_color); ?>;
		height: 100%;
		display: inline-block;
	    padding: 0 60px;
	    vertical-align: middle;
	    padding-right: 8px;	   
		font-weight: normal;
		font-size: 16px;
		position: relative;
		border-radius: 6px;
		letter-spacing: 1px;
		-webkit-transition: all .25s ease-in-out;
    	transition: all .25s ease-in-out;
	}
	.cspt-header-style-1 .cspt-header-button a:after {
	    content: "\e83f";
	    font-family: "creativesplanet-base-icons";	   
	    font-size: 45px;
	    line-height: 45px;
	    top: 3px;
	    position: absolute;
	    left: 0;	   
	    color: <?php echo esc_attr($global_color); ?>;
	    font-weight: normal;
	}
	.cspt-header-style-1 .cspt-header-button a span{
		display: block;
	}
	.cspt-header-style-1 .cspt-header-button .cspt-header-button-text-1{
		font-weight: 700;		
		margin-bottom: 5px;
	}
	.cspt-header-style-1 .cspt-header-button{
		line-height: normal;
	}
	.cspt-header-style-1 .cspt-sticky-on .cspt-header-button a{
		color: <?php echo esc_attr($blackish_color); ?>;		
	}

	.cspt-header-style-2.site-header .cspt-pre-header-wrapper.cspt-bg-color-blackish{
		background-color: <?php echo cspt_hex2rgb($blackish_bg_color, '0.65') ?>;;
	}
	.cspt-header-style-2 .cspt-header-content {		
		position: relative;
	}
	.cspt-header-style-2 .site-branding{
		margin-right: 80px;
	}
	.cspt-header-style-2 .cspt-navbar div > ul > li > a{
		margin: 0 15px;
	}
	.cspt-header-style-2 .cspt-navbar.cspt-bigger-menu div > ul > li > a{
		margin: 0 10px;
	}
	.cspt-header-style-2 .cspt-right-box {
	    margin-left: 10px;
	    display: flex;
	}
	.cspt-header-style-2 .cspt-logo-menuarea {
	    display: -ms-flexbox!important;
	    display: flex!important;
	}
	.cspt-header-style-2 .cspt-header-button {
		line-height: normal;
	}
	.cspt-header-style-2 .cspt-header-button a{	
		text-transform: uppercase;
		color: #fff;
		border: 2px solid #fff;
		height: 100%;
		display: inline-block;
		background-color: transparent ;
	    vertical-align: middle;
		padding: 10px 40px;   
		position: relative;
		border-radius: 0; 
		-webkit-transition: all .25s ease-in-out;
    	transition: all .25s ease-in-out;
	}
	.cspt-header-style-2 .cspt-header-button a:hover{
		background-color: #fff;
		color: <?php echo esc_attr($blackish_color); ?>;
	}
	.cspt-header-style-2 .cspt-header-button{
		line-height: normal;
	}
	.cspt-header-style-2 .cspt-pre-header-wrapper .container {
		max-width: none;
		padding: 0;
	}
	.cspt-header-style-2 .cspt-right-box  .cspt-cart-details{
		position: relative;
	}
	.cspt-header-style-2 .cspt-right-box .cspt-cart-wrapper .cspt-cart-count{
		position: absolute;
		width: 25px;
		height: 25px;
		line-height: 25px;
		background-color: #fff;
		top: -25px;
		left: 0;
		border-radius: 50%;
		color: <?php echo esc_attr($blackish_color); ?>;
		text-align: center;
		font-size: 14px;
	}
	.cspt-header-style-2 .cspt-right-box .cspt-cart-wrapper,
	.cspt-header-style-2 .cspt-right-box .cspt-header-search-btn {
		display: flex;
		align-items: center;
		margin-right: 20px;
	}
	.cspt-header-style-2 .cspt-right-box .cspt-cart-wrapper,
	.cspt-header-style-2 .cspt-right-box .cspt-cart-wrapper a,
	.cspt-header-style-2 .cspt-right-box .cspt-header-search-btn a{
		color: <?php echo esc_attr($main_menu_typography['color']); ?>;
		font-size: 18px;
	}
	.cspt-header-style-2 .cspt-bg-color-transparent:not(.cspt-sticky-on) .cspt-navbar.cspt-main-active-color-globalcolor > div > ul >li:hover > a,
	.cspt-header-style-2 .cspt-bg-color-transparent:not(.cspt-sticky-on) .cspt-navbar.cspt-main-active-color-globalcolor > div > ul >li.current-menu-parent > a{
		color: rgba(255, 255, 255, 0.90);
	}

	/*==== cspt-header-style-3 ====*/
	.cspt-header-style-3 .cspt-right-box .cspt-header-search-form-wrapper{
		border-right: 1px solid  rgba(0, 0, 0, 0.10);
	}
	.cspt-header-style-3 .cspt-right-box .cspt-header-search-form-wrapper{
		border-left: 1px solid  rgba(0, 0, 0, 0.10);
	}
	.cspt-header-style-3 .cspt-header-button a{
		color: #fff;		
		height: 100%;
		display: inline-block;
		padding: 0 30px;
		padding-right: 20px;
	    vertical-align: top;	  
	    line-height: 55px;
	    height: 55px;
		background-color: <?php echo esc_attr($blackish_bg_color); ?>;
	    text-transform: uppercase;
		font-weight: 700;
		font-size: 13px;
		position: relative;		
		letter-spacing: 1px;
		-webkit-transition: all .25s ease-in-out;
   		transition: all .25s ease-in-out;
	}
	.cspt-header-style-3 .cspt-header-button a:hover{
		background-color: <?php echo esc_attr($global_color); ?>;
	}
	.cspt-header-style-3 .cspt-header-button a:after {
	    content: "\e810";
	    font-family: "creativesplanet-base-icons";

	    font-size: 16px;
	    top: 0;
	    position: relative;
	    font-weight: bold;	    
	    padding: 14px 10px;	  
	} 
	.cspt-header-style-3 .cspt-header-info-inner .cspt-header-box-icon i{
		color: <?php echo esc_attr($global_color); ?>;
	}
	.cspt-header-style-3 .cspt-header-button{
		vertical-align: middle;
	}

	<?php if( !empty($main_menu_typography['color']) ){
		?>
		.cspt-header-style-3 .cspt-right-box ul.cspt-social-links li a,
		.cspt-header-style-3 .cspt-right-box .cspt-cart-link,
		.cspt-header-style-3  .cspt-header-search-btn a {
			color: <?php echo esc_attr($main_menu_typography['color']); ?>;
		}
		<?php
	}
	?>

	/*=== cspt-header-style-4 ===*/	
	.cspt-header-style-4.site-header .cspt-header-height-wrapper{
		margin-top: 40px;
	}
	 
	.cspt-header-style-4 .cspt-sticky-on .cspt-pre-header-wrapper {
		height: 0;
		line-height: 0;
		display: none;
	}
	.cspt-header-style-4.site-header .cspt-pre-header-wrapper.cspt-bg-color-blackish{
		background-color: <?php echo cspt_hex2rgb($blackish_bg_color, '0.65') ?>;;
	}
	.cspt-header-style-4 .cspt-header-overlay {
		position: absolute;
		z-index: 9;
		width: 100%;
	}
	.cspt-header-style-4 .cspt-header-content {
		margin: 0 0px;
		position: relative;
	}
	.cspt-header-style-4 .site-branding{
		margin-left: 20px;
	}
	.cspt-header-style-4 .cspt-navbar div > ul > li > a{
		margin: 0 15px;
	}
	.cspt-header-style-4 .cspt-navbar.cspt-bigger-menu div > ul > li > a{
		margin: 0 10px;
	}
	.cspt-header-style-4 .cspt-right-box {
	    margin-left: 10px;
		display: flex;
		margin-right: 20px;
	}
	.cspt-header-style-4 .cspt-logo-menuarea {
	    display: -ms-flexbox!important;
	    display: flex!important;
	}
	.cspt-header-style-4 .cspt-header-button{
		display: flex;
		line-height: <?php echo esc_attr($header_height); ?>px !important;
		height: <?php echo esc_attr($header_height); ?>px;
		align-items: center;

		position: relative;
		padding-left: 70px;
		border-left: 1px solid #eee;
	}
	.cspt-header-style-4 .cspt-header-button:after{
		content: "\e847";
		font-family: "creativesplanet-base-icons";
		position: absolute;
		left: 21px;
		font-size: 30px;
		color: #ff8242;
	}
	.cspt-header-style-4 .cspt-header-button a span{
		display: block;
	}
	.cspt-header-style-4 .cspt-sticky-on .cspt-header-button{	
		line-height: <?php echo esc_attr($sticky_header_height); ?>px !important;
		height: <?php echo esc_attr($sticky_header_height); ?>px;
	}
	.cspt-header-style-4 .cspt-header-button a{
		line-height: normal;
	}
	.cspt-header-style-4 .cspt-header-button a span.cspt-header-button-text-1{
		font-size: 15px;
		color: #999;
		font-weight: normal;
		text-transform: uppercase;
	}
	.cspt-header-style-4 .cspt-header-button a span.cspt-header-button-text-2{
		font-size: 22px;
		font-weight: 700;
	}
	.cspt-header-style-4 .cspt-right-box .cspt-cart-wrapper,
	.cspt-header-style-4 .cspt-right-box .cspt-header-search-btn {
		display: flex;
		align-items: center;
		margin-right: 20px;
	}
	.cspt-header-style-4 .cspt-title-bar-content{
		padding-top: 200px;
	}
	.cspt-header-style-4 .cspt-contact-info li{
		text-transform: uppercase;
		letter-spacing: 0.5px;
		font-size: 14px;
	}

	/*=== cspt-header-style-5 ===*/
	.cspt-header-style-5 .cspt-header-overlay {
		position: absolute;
		z-index: 9;
		width: 100%;
	}
	.cspt-header-style-5 .cspt-header-content {
		margin: 0 50px;
		position: relative;
	}
	.cspt-header-style-5 .cspt-pre-header-wrapper .container{
		max-width: none;
		padding: 0 50px
	}
	.cspt-header-style-5 .site-branding.cspt-logo-area {
	    margin-right: 80px;
	}
	.cspt-header-style-5 .cspt-logo-menuarea{
		display: -ms-flexbox!important;
		display: flex!important;
		-webkit-box-pack: justify!important;
		-ms-flex-pack: justify!important;
		justify-content: space-between!important;
	}
	.cspt-header-style-5 .cspt-right-box{
	    margin-left: 10px;
	    display: flex;
	    align-items: center;
	}
	.cspt-header-style-5 .cspt-right-box{
		line-height: <?php echo esc_attr($header_height); ?>px !important;
		height: <?php echo esc_attr($header_height); ?>px;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-right-box{
		line-height: <?php echo esc_attr($sticky_header_height); ?>px !important;
		height: <?php echo esc_attr($sticky_header_height); ?>px;
	}
	.cspt-header-style-5 .cspt-header-button a{
		color: #fff;		
		height: 100%;
		display: inline-block;
	    padding: 0 60px;
	    vertical-align: middle;
	    padding-right: 8px;	   
		font-weight: normal;
		font-size: 16px;
		position: relative;
		border-radius: 6px;
		letter-spacing: 1px;
		-webkit-transition: all .25s ease-in-out;
    	transition: all .25s ease-in-out;
	}
	.cspt-header-style-5 .cspt-header-button a:after {
	    content: "\e847";
	    font-family: "creativesplanet-base-icons";	   
	    font-size: 40px;
	    line-height: 45px;
	    top: 3px;
	    position: absolute;
	    left: 0;	   
	    color: #fff;
	    font-weight: normal;
	}
	.cspt-header-style-5 .cspt-header-button a span{
		display: block;
	}
	.cspt-header-style-5 .cspt-header-button .cspt-header-button-text-1{
		font-weight: 700;		
		margin-bottom: 5px;
		text-transform: uppercase;
	}
	.cspt-header-style-5 .cspt-header-button .cspt-header-button-text-2{
		font-size: 20px;
	}
	.cspt-header-style-5 .cspt-header-button{
		line-height: normal;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-header-button a{
		color: <?php echo esc_attr($blackish_color); ?>;		
	}
	.cspt-header-style-5 .navigation-top{
	  margin-left: auto!important;
	}
	.cspt-header-style-5  .cspt-navbar div > ul > li > a {
	    margin: 0 22px;
	}
	.cspt-header-style-5 .cspt-right-box .cspt-cart-wrapper, 
	.cspt-header-style-5 .cspt-right-box .cspt-header-search-btn {
	    display: flex;
	    align-items: center;
	    margin-right: 30px;
	}
	.cspt-header-style-5 .cspt-title-bar-content{
		padding-top: 180px;
	}
	.cspt-header-style-5 .cspt-right-box .cspt-cart-link,
	.cspt-header-style-5  .cspt-header-search-btn a{
		font-size: 16px;
	}
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-social-links:before,
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-header-search-btn:before,
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-header-search-btn:after, 
	.cspt-header-style-5 .cspt-contact-info:after,
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-contact-info li:after,
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-pre-header-right > *:after {
		content: "";
		position: absolute;
		left: 0px;
		top: 0;
		width: 1px;
		height: 49px;
		background-color: rgba(255,255,255, .13);
	}
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-social-links:before,
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-header-search-btn:after,
	.cspt-header-style-5 .cspt-contact-info:after {
		left: auto;
		right: 0;
	}
	.cspt-header-style-5.site-header .cspt-bg-color-transparent,
	.cspt-header-style-5 .cspt-header-height-wrapper > .cspt-bg-color-transparent {
		border-bottom: 1px solid rgba(255, 255, 255, 0.13);
	}
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-social-links, 
	.cspt-header-style-5 .cspt-pre-header-wrapper .cspt-header-search-btn,
	.cspt-header-style-5 .cspt-contact-info li {
		padding: 0 15px;
		text-transform: uppercase;
		letter-spacing: 0.5px;
		font-size: 14px;
	}

	/*** Custom Menu text color ***/
	.cspt-header-style-5 .cspt-sticky-on .cspt-right-box .cspt-cart-link,
	.cspt-header-style-5 .cspt-sticky-on .cspt-header-search-btn a,
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar div > ul > li > a{
		color: <?php echo esc_attr($main_menu_sticky_color); ?>;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-pre-header-wrapper{
		height: 0;
		line-height: 0;
		display: none;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li{
		position: relative;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li:hover:after,
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current_page_item:after,
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current-menu-parent:after{
		content: ' ';
		width: 100%;
		height: 2px;
		position: absolute;
		bottom: -2px;
		left: 0;
		background: #fff;
		-webkit-transition: all 0.3s linear 0s;
		transition: all 0.3s linear 0s;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li:hover > a,
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li > a:hover, 
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current_page_item > a, 
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current-menu-parent > a{
		color: #fff;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-blackish > div > ul > li.current_page_item > a, 
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-blackish  > div > ul > li.current-menu-parent > a{
		color: #232323;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-white > div > ul > li.current_page_item > a, 
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-white  > div > ul > li.current-menu-parent > a{
		color: #fff;
	}
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-secondarycolor > div > ul > li.current_page_item > a, 
	.cspt-header-style-5 .cspt-navbar.cspt-main-active-color-secondarycolor  > div > ul > li.current-menu-parent > a{
		color: #eee;
	}
	.cspt-header-style-5 .cspt-navbar ul ul{
		border-top: 3px solid #fff;
	}
	.cspt-header-style-5 .cspt-sticky-on{
		color: <?php echo esc_attr($blackish_color); ?>;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li:hover:after,
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current_page_item:after,
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current-menu-parent:after{
		height: 0;
		background: transparent;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-header-button a:after,
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li:hover > a,
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li > a:hover, 
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current_page_item > a, 
	.cspt-header-style-5 .cspt-sticky-on .cspt-navbar.cspt-main-active-color-globalcolor > div > ul > li.current-menu-parent > a{
		color: <?php echo esc_attr($global_color); ?>;
	}

	<?php if( !empty($main_menu_typography['color']) ){
		?>
		.cspt-header-style-5 .cspt-header-button a,
		.cspt-header-style-5 .cspt-right-box .cspt-cart-link,
		.cspt-header-style-5  .cspt-header-search-btn a {
			color: <?php echo esc_attr($main_menu_typography['color']); ?>;
		}
		<?php
	}
	?>

	.cspt-header-style-5 .cspt-sticky-on .cspt-header-button a,
	.cspt-header-style-5 .cspt-sticky-on .cspt-right-box .cspt-cart-link,
	.cspt-header-style-5 .cspt-sticky-on .cspt-header-search-btn a {
		color: <?php echo esc_attr($main_menu_sticky_color); ?>;
	}
	.cspt-header-style-5 .cspt-right-box .cspt-cart-details{
		position: relative;
	}
	.cspt-header-style-5 .cspt-right-box .cspt-cart-details .cspt-cart-count{
		position: absolute;
		background-color: <?php echo esc_attr($main_menu_typography['color']); ?>;
		color: #24292f;
		border-radius: 50%;
		top: -25px;
		right: -2px;
		display: inline-block;
		height: 25px;
		width: 25px;
		line-height: 25px;
		text-align: center;
		font-size: 13px;
	}
	.cspt-header-style-5 .cspt-right-box .cspt-base-icon-supermarket-2:before{
		font-weight: 700;
	}
	.cspt-header-style-5 .cspt-sticky-on .cspt-right-box .cspt-cart-details .cspt-cart-count{		
		background-color: <?php echo esc_attr($main_menu_sticky_color); ?>;
		color: #fff;
	}

}
/*====================================  End Min Break Point  ====================================*/

<?php if( !empty($preheader_responsive) ){ ?>
@media screen and (max-width: <?php echo esc_html($preheader_responsive); ?>px) {
	.cspt-pre-header-wrapper{
		display: none;
	}
}
<?php } ?>
<?php
$footer_column	= cspt_get_base_option('footer-column');
if( $footer_column=='custom' ) :
	$footer_column_1	= cspt_get_base_option('footer-1-col-width');
	$footer_column_2	= cspt_get_base_option('footer-2-col-width');
	$footer_column_3	= cspt_get_base_option('footer-3-col-width');
	$footer_column_4	= cspt_get_base_option('footer-4-col-width');
	?>
	@media screen and (min-width: 992px) {
		<?php if( !empty($footer_column_1) && $footer_column_1!='hide' ) : ?>
		.site-footer .cspt-footer-widget.cspt-footer-widget-col-1{
			-ms-flex: 0 0 <?php echo esc_attr($footer_column_1) ?>%;
			flex: 0 0 <?php echo esc_attr($footer_column_1) ?>%;
			max-width: <?php echo esc_attr($footer_column_1) ?>%;
		}
		<?php endif; ?>
		<?php if( !empty($footer_column_2) && $footer_column_2!='hide' ) : ?>
		.site-footer .cspt-footer-widget.cspt-footer-widget-col-2{
			-ms-flex: 0 0 <?php echo esc_attr($footer_column_2) ?>%;
			flex: 0 0 <?php echo esc_attr($footer_column_2) ?>%;
			max-width: <?php echo esc_attr($footer_column_2) ?>%;
		}
		<?php endif; ?>
		<?php if( !empty($footer_column_3) && $footer_column_3!='hide' ) : ?>
		.site-footer .cspt-footer-widget.cspt-footer-widget-col-3{
			-ms-flex: 0 0 <?php echo esc_attr($footer_column_3) ?>%;
			flex: 0 0 <?php echo esc_attr($footer_column_3) ?>%;
			max-width: <?php echo esc_attr($footer_column_3) ?>%;
		}
		<?php endif; ?>
		<?php if( !empty($footer_column_4) && $footer_column_4!='hide' ) : ?>
		.site-footer .cspt-footer-widget.cspt-footer-widget-col-4{
			-ms-flex: 0 0 <?php echo esc_attr($footer_column_4) ?>%;
			flex: 0 0 <?php echo esc_attr($footer_column_4) ?>%;
			max-width: <?php echo esc_attr($footer_column_4) ?>%;
		}
		<?php endif; ?>
	}
<?php endif; ?>
