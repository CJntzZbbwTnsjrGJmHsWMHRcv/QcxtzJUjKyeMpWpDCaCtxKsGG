"use strict";

/*----  Functions  ----*/

/* ====================================== */
/* Reset and rearrange Stretched Column
/* ====================================== */
var cspt_rearrange_stretched_col = function( model_id ) {
	if( jQuery('body').hasClass('elementor-editor-active') ){
		jQuery( '*[data-id="'+model_id+'"]' ).each(function(){
			jQuery('.cspt-stretched-div', this).remove();
			jQuery('.elementor-widget-wrap', this).removeAttr('style');
			setTimeout(function(){ cspt_stretched_col(); }, 50);
		});	
	}
}

/* ====================================== */
/* Stretched Column
/* ====================================== */
var cspt_stretched_col = function() {

	jQuery('.elementor-section-wrap > .elementor-section').each(function(){
		if( jQuery(this).hasClass('cspt-col-stretched-left') || jQuery(this).hasClass('cspt-col-stretched-right') || jQuery(this).hasClass('cspt-col-stretched-both') ){
			jQuery(this).addClass('cspt-col-stretched-yes').removeClass('cspt-col-stretched-no');
		} else {
			jQuery(this).addClass('cspt-col-stretched-no').removeClass('cspt-col-stretched-yes');
		}
	});

	// remove all stretched related changes in each column
	jQuery('.elementor-section-wrap > .elementor-section').each(function(){
		var ThisSection = jQuery(this);
		var ThisColumn	= '';
		jQuery( '.elementor-column:not(.elementor-inner-column)', ThisSection ).each(function(){
			ThisColumn	= jQuery(this);
			jQuery( '.cspt-stretched-div', ThisColumn ).remove();
			ThisColumn.removeClass('cspt-col-stretched-yes cspt-col-stretched-left cspt-col-stretched-right cspt-col-stretched-content-yes');
		});
	});

	jQuery('.elementor-section-wrap > .elementor-section.cspt-col-stretched-yes').each(function(){

		var ThisSection		= jQuery(this);
		var ThisColumn		= '';
		var ColWrapper		= '';
		var StretchedEle	= '';

		if( ThisSection.hasClass('cspt-col-stretched-left') || ThisSection.hasClass('cspt-col-stretched-both') ){
			ThisColumn = jQuery( '.elementor-column:not(.elementor-inner-column):first-child', ThisSection );

			if( jQuery('.cspt-stretched-div', ThisColumn).length==0 ){
				ColWrapper = ThisColumn.children('.elementor-widget-wrap');
				ColWrapper.prepend( '<div class="cspt-stretched-div"></div>' );

				// Stretched Element
				StretchedEle = ColWrapper.children('.cspt-stretched-div');

				StretchedEle.addClass( 'cspt-stretched-left' );
				ThisColumn.addClass('cspt-col-stretched-yes cspt-col-stretched-left');

				if( ThisSection.hasClass('cspt-left-col-stretched-content-yes') ){
					ThisColumn.addClass('cspt-col-stretched-content-yes');
				} else {
					ThisColumn.removeClass('cspt-col-stretched-content-yes');
				}

				// background move to stretched div
				ColWrapper.css('background-image', '');
				var bgImage =  ColWrapper.css('background-image');
				if( bgImage!='none' && bgImage!='' ){
					StretchedEle.css('background-image', bgImage );
					ColWrapper.css('background-image', 'none');
				}

				// border radious
				ColWrapper.css('border-top-left-radius', '');
				ColWrapper.css('border-top-right-radius', '');
				ColWrapper.css('border-bottom-left-radius', '');
				ColWrapper.css('border-bottom-right-radius', '');
				var radius_t_left  =  ColWrapper.css('border-top-left-radius');
				var radius_t_right =  ColWrapper.css('border-top-right-radius');
				var radius_b_left  =  ColWrapper.css('border-bottom-left-radius');
				var radius_b_right =  ColWrapper.css('border-bottom-right-radius');
				if( radius_t_left!='0' && radius_t_left!='' ){
					StretchedEle.css('border-top-left-radius', radius_t_left );
					ColWrapper.css('border-top-left-radius', '0');
				}
				if( radius_t_right!='0' && radius_t_right!='' ){
					StretchedEle.css('border-top-right-radius', radius_t_right );
					ColWrapper.css('border-top-right-radius', '0');
				}
				if( radius_b_left!='0' && radius_b_left!='' ){
					StretchedEle.css('border-bottom-left-radius', radius_b_left );
					ColWrapper.css('border-bottom-left-radius', '0');
				}
				if( radius_b_right!='0' && radius_b_right!='' ){
					StretchedEle.css('border-bottom-right-radius', radius_b_right );
					ColWrapper.css('border-bottom-right-radius', '0');
				}

				// Background Color
				var bgColor = ColWrapper.css('background-color');
				if( bgColor!='' ){
					StretchedEle.css('background-color', bgColor );
					ColWrapper.css('background-color', 'transparent');
				}

				// Background Position
				var bgPosition = ColWrapper.css('background-position');
				if( bgPosition!='' ){
					StretchedEle.css('background-position', bgPosition );
				}

				// Background Repeat
				var bgRepeat = ColWrapper.css('background-repeat');
				if( bgRepeat!='' ){
					StretchedEle.css('background-repeat', bgRepeat );
				}

				// Background Size
				var bgSize = ColWrapper.css('background-size');
				if( bgSize!='' ){
					StretchedEle.css('background-size', bgSize );
				}

				cspt_stretched_col_calc();

			}

		}

		if( ThisSection.hasClass('cspt-col-stretched-right') || ThisSection.hasClass('cspt-col-stretched-both') ){
			ThisColumn = jQuery( '.elementor-column:not(.elementor-inner-column):last-child', ThisSection );

			if( jQuery('.cspt-stretched-div', ThisColumn).length==0 ){
				ColWrapper = ThisColumn.children('.elementor-widget-wrap');
				ColWrapper.prepend( '<div class="cspt-stretched-div"></div>' );

				// Stretched Element
				StretchedEle = ColWrapper.children('.cspt-stretched-div');

				StretchedEle.addClass( 'cspt-stretched-right' );
				ThisColumn.addClass('cspt-col-stretched-yes cspt-col-stretched-right');

				if( ThisSection.hasClass('cspt-right-col-stretched-content-yes') ){
					ThisColumn.addClass('cspt-col-stretched-content-yes');
				} else {
					ThisColumn.removeClass('cspt-col-stretched-content-yes');
				}

				// background move to stretched div
				ColWrapper.css('background-image', '');
				var bgImage = ColWrapper.css('background-image');
				if( bgImage!='none' && bgImage!='' ){
					StretchedEle.css('background-image', bgImage );
					ColWrapper.css('background-image', 'none');
				}

				// border radious
				ColWrapper.css('border-top-left-radius', '');
				ColWrapper.css('border-top-right-radius', '');
				ColWrapper.css('border-bottom-left-radius', '');
				ColWrapper.css('border-bottom-right-radius', '');
				var radius_t_left  =  ColWrapper.css('border-top-left-radius');
				var radius_t_right =  ColWrapper.css('border-top-right-radius');
				var radius_b_left  =  ColWrapper.css('border-bottom-left-radius');
				var radius_b_right =  ColWrapper.css('border-bottom-right-radius');
				if( radius_t_left!='0' && radius_t_left!='' ){
					StretchedEle.css('border-top-left-radius', radius_t_left );
					ColWrapper.css('border-top-left-radius', '0');
				}
				if( radius_t_right!='0' && radius_t_right!='' ){
					StretchedEle.css('border-top-right-radius', radius_t_right );
					ColWrapper.css('border-top-right-radius', '0');
				}
				if( radius_b_left!='0' && radius_b_left!='' ){
					StretchedEle.css('border-bottom-left-radius', radius_b_left );
					ColWrapper.css('border-bottom-left-radius', '0');
				}
				if( radius_b_right!='0' && radius_b_right!='' ){
					StretchedEle.css('border-bottom-right-radius', radius_b_right );
					ColWrapper.css('border-bottom-right-radius', '0');
				}

				// Background Color
				var bgColor = ColWrapper.css('background-color');
				if( bgColor!='' ){
					StretchedEle.css('background-color', bgColor );
					ColWrapper.css('background-color', 'transparent');
				}

				// Background Position
				var bgPosition = ColWrapper.css('background-position');
				if( bgPosition!='' ){
					StretchedEle.css('background-position', bgPosition );
				}

				// Background Repeat
				var bgRepeat = ColWrapper.css('background-repeat');
				if( bgRepeat!='' ){
					StretchedEle.css('background-repeat', bgRepeat );
				}

				// Background Size
				var bgSize = ColWrapper.css('background-size');
				if( bgSize!='' ){
					StretchedEle.css('background-size', bgSize );
				}

				cspt_stretched_col_calc();
			}
		}

	});

};

var cspt_stretched_col_calc = function() {

	// padding left or right
	if( jQuery('.elementor-section-wrap > .elementor-section > .elementor-container > .elementor-column.cspt-col-stretched-yes').length>0 ){

		// Returns width of browser viewport
		var window_width = jQuery( window ).width();

		// Returns width of HTML document
		var document_width = jQuery( document ).width();

		jQuery('.elementor-section-wrap > .elementor-section > .elementor-container > .elementor-column.cspt-col-stretched-yes').each(function(){

			var this_ele    = jQuery(this);
			var curr_width  = jQuery(this).closest('.elementor-section').width();
			var extra_width = ((window_width - curr_width)/2);
			var parent_width = '';

			var position = 'left';
			if( jQuery(this).hasClass('cspt-col-stretched-right') ){
				position = 'right';
			}
			
			// set width to 100% if parent is 100%
			parent_width = jQuery('.elementor-widget-wrap', jQuery(this)).parent().width();
			if( parent_width == '100%' ){
				jQuery('.elementor-widget-wrap', jQuery(this)).css('width','100%');
			} else {
				jQuery('.elementor-widget-wrap', jQuery(this)).css('width','');
			}

			jQuery('.cspt-stretched-div', jQuery(this)).css( 'margin-'+position,'-'+extra_width+'px' );

			// stretched column content too
			if( jQuery(this).hasClass('cspt-col-stretched-content-yes') ){
				var stretched_width = jQuery('.cspt-stretched-div', jQuery(this) ).width();
				jQuery(this).children('.elementor-widget-wrap').css( 'margin-'+position,'-'+extra_width+'px' );
				jQuery(this).children('.elementor-widget-wrap').css( 'width', stretched_width+'px' );
				jQuery('.cspt-stretched-div', jQuery(this)).css( 'margin-'+position,'' );

			} else {
				jQuery(this).children('.elementor-widget-wrap').css( 'margin-'+position,'' );
				jQuery(this).children('.elementor-widget-wrap').css( 'width', '' );				
			}
		});
	}

}



/* ============================================== */
/* BG Image yes class in each Section and Column
/* ============================================== */
var cspt_bgimage_class = function() {
	jQuery('.elementor-section').each(function() {
		if( jQuery(this).css('background-image')!='' && jQuery(this).css('background-image')!='none' ){
			jQuery(this).addClass('cspt-bgimage-yes' ).removeClass('cspt-bgimage-no' );
		} else {
			jQuery(this).addClass('cspt-bgimage-no' ).removeClass('cspt-bgimage-yes' );
		}
	});
	jQuery('.elementor-column').each(function() {
		if( jQuery(this).children('.elementor-widget-wrap').children('.cspt-stretched-div').length ){
			if( jQuery(this).children('.elementor-widget-wrap').children('.cspt-stretched-div').css('background-image')!='' && jQuery(this).children('.elementor-widget-wrap').children('.cspt-stretched-div').css('background-image')!='none' ){
				jQuery(this).addClass('cspt-bgimage-yes' ).removeClass('cspt-bgimage-no' );
			} else {
				jQuery(this).addClass('cspt-bgimage-no' ).removeClass('cspt-bgimage-yes' );
			}
		} else {
			if( jQuery(this).children('.elementor-widget-wrap').css('background-image')!='' && jQuery(this).children('.elementor-widget-wrap').css('background-image')!='none' ){
				jQuery(this).addClass('cspt-bgimage-yes' ).removeClass('cspt-bgimage-no' );
			} else {
				jQuery(this).addClass('cspt-bgimage-no' ).removeClass('cspt-bgimage-yes' );
			}
		}
	});
};

/* ============================================== */
/* BG Color yes class in each Section and Column
/* ============================================== */
var cspt_bgcolor_class = function() {
	jQuery('.elementor-section').each(function() {
		if( jQuery(this).css('background-color')!='' && jQuery(this).css('background-color')!='transparent' ){
			jQuery(this).addClass('cspt-bgcolor-yes');
		}
	});
	jQuery('.elementor-column').each(function() {
		if( jQuery(this).children('.cspt-stretched-div').length ){
			if( jQuery(this).children('.cspt-stretched-div').css('background-color')!='' && jQuery(this).children('.cspt-stretched-div').css('background-color')!='transparent' ){
				jQuery(this).addClass('cspt-bgcolor-yes' ).removeClass('cspt-bgcolor-no' );
			} else {
				jQuery(this).addClass('cspt-bgcolor-no' ).removeClass('cspt-bgcolor-yes' );
			}
		} else {
			if( jQuery(this).children('.elementor-widget-wrap').css('background-color')!='' && jQuery(this).children('.elementor-widget-wrap').css('background-color')!='transparent' ){
				jQuery(this).addClass('cspt-bgcolor-yes' ).removeClass('cspt-bgcolor-no' );
			} else {
				jQuery(this).addClass('cspt-bgcolor-no' ).removeClass('cspt-bgcolor-yes' );
			}
		}
	});
};


/*----  Events  ----*/

// On resize
jQuery(window).resize(function(){
	setTimeout(function() {
		cspt_stretched_col_calc();
	}, 100);
});

// on ready
jQuery(document).ready(function(){
	cspt_stretched_col();
	cspt_stretched_col_calc();
	cspt_bgimage_class();
	cspt_bgcolor_class();
});	

// on load
jQuery(window).on( 'load', function(){
	cspt_stretched_col_calc();
});
