"use strict";

/*----  Functions  ----*/

jQuery.fn.cspt_is_bound = function(type) {
	if( this.data('events') !== undefined ){
		if (this.data('events')[type] === undefined || this.data('events')[type].length === 0) {
			return false;
		}
		return (-1 !== $.inArray(fn, this.data('events')[type]));
	} else {
		return false;
	}
};

var cspt_box_link = function() {
	jQuery('.cspt-link-whole-box-yes').each(function(){
		if( jQuery('.cspt-ihbox-btn a' , this ).length > 0 ){
			var url = jQuery('.cspt-ihbox-btn a' , this ).attr('href');
			jQuery(this).wrapInner('<a href="'+url+'"></a>'); 
		}
	});
}

var cspt_sticky_header = function() {
	if( jQuery('.cspt-header-sticky-yes').length > 0 ){

		if( jQuery('.cspt-header-sticky-yes').closest('#masthead').hasClass('cspt-header-style-2') ){
			var thisHeight = jQuery('.cspt-header-sticky-yes').height();
			jQuery('.cspt-header-height-wrapper').css( 'min-height', thisHeight+'px' );
		}

		var offset_px = 0;
		if( jQuery('#wpadminbar').length>0 && (self===top) ){
			offset_px = jQuery('#wpadminbar').height();
		}
		jQuery('.cspt-header-menu-area.cspt-header-sticky-yes').parent().css('height', jQuery('.cspt-header-menu-area.cspt-header-sticky-yes').height() );
		if( jQuery(document).width()>cspt_js_variables.responsive ){
			jQuery( '.cspt-header-sticky-yes' ).stick_in_parent({ 'parent':'body', 'spacer':false, 'offset_top':offset_px, 'sticky_class':'cspt-sticky-on'}).addClass('cspt-sticky-applied');
		} else {
			if( jQuery( '.cspt-header-sticky-yes' ).hasClass('cspt-sticky-applied') ){
				jQuery( '.cspt-header-sticky-yes' ).trigger("sticky_kit:detach").removeClass('cspt-sticky-applied');
			}
		}
	}
}

var cspt_toggleSidebar = function() {
	jQuery(".cspt-navbar > div").toggleClass("active");
	if( jQuery('.cspt-navbar > div > .closepanel').length==0 ){
		jQuery('.cspt-navbar > div').append("<span class='closepanel'><i class='cspt-base-icon-cancel'></i></span>");
		jQuery('.cspt-navbar > div > .closepanel').on('click', function(){	    		
			jQuery('.nav-menu-toggle').trigger('click');	    		
		});
	}
}

var cspt_sorting = function() {
	jQuery('.cspt-sortable-yes').each(function(){
		var boxes	= jQuery('.cspt-element-posts-wrapper', this );
		var links	= jQuery('.cspt-sortable-list a', this );			
		boxes.isotope({
			animationEngine : 'best-available'
		});
		links.on('click', function(e){
			var selector = jQuery(this).data('sortby');
			if( selector != '*' ){
				var selector = '.' + selector;
			}
			boxes.isotope({
				filter			: selector,
				itemSelector	: '.cspt-ele',
				layoutMode		: 'fitRows'
			});
			links.removeClass('cspt-selected');
			jQuery(this).addClass('cspt-selected');
			e.preventDefault();
		});
	});
}

var cspt_back_to_top = function() {
	// scroll-to-top
	var btn = jQuery('.scroll-to-top');
	jQuery(window).scroll(function() {
	if (jQuery(window).scrollTop() > 300) {
		btn.addClass('show');
	} else {
		btn.removeClass('show');
	}
	});
	btn.on('click', function(e) {
	e.preventDefault();
	jQuery('html, body').animate({scrollTop:0}, '300');
	});
}

var cspt_navbar = function() {
	if( !jQuery('ul#cspt-top-menu > li > a[href="#"]').cspt_is_bound('click') ) {
		jQuery('ul#cspt-top-menu > li > a[href="#"]').click(function(){ return false; });
	}
	
	jQuery('.cspt-navbar > div > ul li:has(ul)').append("<span class='sub-menu-toggle'><i class='cspt-base-icon-down-open-big'></i></span>");
	jQuery('.cspt-navbar li').hover(function() {
		if(jQuery(this).children("ul").length == 1) {
			var parent		= jQuery(this);
			var child_menu	= jQuery(this).children("ul");
			if( jQuery(parent).offset().left + jQuery(parent).width() + jQuery(child_menu).width() > jQuery(window).width() ){
				jQuery(child_menu).addClass('cspt-nav-left');
			} else {
				jQuery(child_menu).removeClass('cspt-nav-left');
			}
		}
	});
	jQuery(".nav-menu-toggle").on("click tap", function() {
		cspt_toggleSidebar();
	});
	jQuery('.sub-menu-toggle').on( 'click', function() {
		if(jQuery(this).siblings('.sub-menu, .children').hasClass('show')){
			jQuery(this).siblings('.sub-menu, .children').removeClass('show');
			jQuery( 'i', jQuery(this) ).removeClass('cspt-base-icon-up-open-big').addClass('cspt-base-icon-down-open-big');
		} else {
			jQuery(this).siblings('.sub-menu, .children').addClass('show');
			jQuery( 'i', jQuery(this) ).removeClass('cspt-base-icon-down-open-big').addClass('cspt-base-icon-up-open-big');
		}
		return false;
	});
	jQuery('.nav-menu-toggle').on( 'click', function(){
		jQuery('.cspt-navbar ul.menu > li > a').on( 'click', function() {
			if( jQuery(this).attr('href')=='#' && jQuery(this).siblings('ul.sub-menu, ul.children').length>0 ){
				jQuery(this).siblings('.sub-menu-toggle').trigger('click');
				return false;
			}
		});
	})
}

var cspt_lightbox = function() {
	var i_type = 'image';
	jQuery('a.cspt-lightbox, a.cspt-lightbox-video, .cspt-lightbox-video a, .cspt-lightbox a').each(function(){
		if( jQuery(this).hasClass('cspt-lightbox-video') || jQuery(this).closest('.elementor-element').hasClass('cspt-lightbox-video') ){
			i_type = 'iframe';
		} else {
			i_type = 'image';
		}
		jQuery(this).magnificPopup({type:i_type});
	});
}

var cspt_video_popup = function() {
	jQuery('.cspt-popup').on('click', function(event) {
		event.preventDefault();
		var href  = jQuery(this).attr('href');
		var title = jQuery(this).attr('title');
		window.open( href , title, "width=600,height=500");
	});
}

var cspt_testimonial = function() {
	jQuery('.cspt-testimonial-active').each(function(){
		var ele_parent = jQuery(this).closest('.cspt-element-posts-wrapper');
		jQuery('.creativesplanet-ele.creativesplanet-ele-testimonial', ele_parent ).on('mouseover', function() {
			jQuery('.creativesplanet-ele.creativesplanet-ele-testimonial', ele_parent ).removeClass('cspt-testimonial-active');
			jQuery(this).addClass('cspt-testimonial-active');
		});
	});
}

var cspt_search_btn = function(){
	jQuery(function() {
		jQuery('.cspt-header-search-btn').on("click", function(event) {
			event.preventDefault();
			jQuery(".cspt-header-search-form-wrapper").addClass("open");
			jQuery('.cspt-header-search-form-wrapper input[type="search"]').focus();
		});
		jQuery(".cspt-search-close").on("click keyup", function(event) {
			jQuery(".cspt-header-search-form-wrapper").removeClass("open");
		});
	});
}

var cspt_gallery = function(){
	jQuery("div.cspt-gallery").each(function(){
		jQuery( this ).lightSlider({ item: 1, auto: true, loop: true, controls: false, speed: 1500, pause: 5500 }); 
	});
}

var cspt_center_logo_header_class = function() {
	if( jQuery('#masthead.cspt-header-style-5 ul#cspt-top-menu').length > 0 ){
		var has_class = jQuery('#masthead.cspt-header-style-5 ul#cspt-top-menu > li').hasClass('cspt-logo-append');
		if( has_class==false ){
			var total_li = jQuery('#masthead.cspt-header-style-5 ul#cspt-top-menu > li').length;
			var li = Math.floor( total_li / 2 );
			jQuery('#masthead.cspt-header-style-5 ul#cspt-top-menu > li:nth-child('+li+')').addClass('cspt-logo-append');
		}
	}
}

var cspt_selectwrap = function(){
	jQuery("select:not(#rating)").each(function(){
		jQuery( this ).wrap( "<div class='cspt-select'></div>" );
	});
}

/* ====================================== */
/* Circle Progress bar
/* ====================================== */
var cspt_circle_progressbar = function() {

	jQuery('.cspt-circle-outer').each(function(){

		var this_circle = jQuery(this);

		// Circle settings
		var emptyFill_val = "rgba(0, 0, 0, 0)";
		var thickness_val = 10;
		var fill_val      = this_circle.data('fill');

		if( typeof this_circle.data('emptyfill') !== 'undefined' && this_circle.data('emptyfill')!='' ){
			emptyFill_val = this_circle.data('emptyfill');
		}
		if( typeof this_circle.data('thickness') !== 'undefined' && this_circle.data('thickness')!='' ){
			thickness_val = this_circle.data('thickness');
		}
		if( typeof this_circle.data('filltype') !== 'undefined' && this_circle.data('filltype')=='gradient' ){
			fill_val = {gradient: [ this_circle.data('gradient1') , this_circle.data('gradient2') ], gradientAngle: Math.PI / 4 };
		}

		if( typeof jQuery.fn.circleProgress == "function" ){
			var digit   = this_circle.data('digit');
			var before  = this_circle.data('before');
			var after   = this_circle.data('after');
			var c_width  = this_circle.data('id');
			var digit       = Number( digit );
			var short_digit = ( digit/100 ); 

			jQuery('.cspt-circle', this_circle ).circleProgress({
				value		: 0,
				size		: c_width,
				startAngle	: -Math.PI / 4 * 2,
				thickness	: thickness_val,
				emptyFill	: emptyFill_val,
				fill		: fill_val
			}).on('circle-animation-progress', function(event, progress, stepValue) { // Rotate number when animating
				this_circle.find('.cspt-circle-number').html( before + Math.round( stepValue*100 ) + after );
			});
		}

		this_circle.waypoint(function(direction) {
			if( !this_circle.hasClass('completed') ){
				// Re draw when view
				if( typeof jQuery.fn.circleProgress == "function" ){
					jQuery('.cspt-circle', this_circle ).circleProgress( { value: short_digit } );
				};
				this_circle.addClass('completed');
			}
		}, { offset:'85%' });

	});
}

/* ====================================== */
/* Carousel
/* ====================================== */
var cspt_carousel = function() {

	jQuery(".creativesplanet-element-viewtype-carousel").each(function() {

		var carouselElement = jQuery( this );

		jQuery('.cspt-ele' , carouselElement).removeClass( function (index, className) {
			return (className.match (/(^|\s)col-md-\S+/g) || []).join(' ');
		}).removeClass( function (index, className) {
			return (className.match (/(^|\s)col-lg-\S+/g) || []).join(' ');
		});

		var columns = jQuery( this ).data('columns');
		var loop = jQuery( this ).data('loop');

		if( columns == '1' ){
			var responsive_items = [ /* 1199 : */ '1', /* 991 : */ '1', /* 767 : */ '1', /* 575 : */ '1', /* 0 : */ '1' ];
		} else if( columns == '2' ){
			var responsive_items = [ /* 1199 : */ '2', /* 991 : */ '2', /* 767 : */ '2', /* 575 : */ '2', /* 0 : */ '1' ];
		} else if( columns == '3' ){
			var responsive_items = [ /* 1199 : */ '3', /* 991 : */ '2', /* 767 : */ '2', /* 575 : */ '2', /* 0 : */ '1' ];
		} else if( columns == '4' ){
			var responsive_items = [ /* 1199 : */ '4', /* 991 : */ '4', /* 767 : */ '3', /* 575 : */ '2', /* 0 : */ '1' ];
		} else if( columns == '5' ){
			var responsive_items = [ /* 1199 : */ '5', /* 991 : */ '4', /* 767 : */ '3', /* 575 : */ '2', /* 0 : */ '1' ];
		} else if( columns == '6' ){
			var responsive_items = [ /* 1199 : */ '6', /* 991 : */ '4', /* 767 : */ '3', /* 575 : */ '2', /* 0 : */ '1' ];
		} else {
			var responsive_items = [ /* 1199 : */ '3', /* 991 : */ '3', /* 767 : */ '3', /* 575 : */ '2', /* 0 : */ '1' ];
		}

		var margin_val = 30;
		if( jQuery(carouselElement).data('margin')!='' ){
			margin_val = jQuery(carouselElement).data('margin');
		}

		var posts_wrapper_class = '.cspt-element-posts-wrapper';
		if( jQuery(carouselElement).hasClass('cspt-element-service-style-2') ){
			posts_wrapper_class = '.cspt-element-posts-wrapper > .cspt-service-2-carousel-area > .cspt-service-2-inner > .row';
		}

		var val_nav = jQuery(carouselElement).data('nav');
		if( val_nav=='above' ){
			val_nav = false;
		}

		var car_options = {
			loop			: jQuery(carouselElement).data('loop'),
			autoplay		: jQuery(carouselElement).data('autoplay'),
			center			: jQuery(carouselElement).data('center'),
			nav				: val_nav,
			dots			: jQuery(carouselElement).data('dots'),
			autoplaySpeed	: jQuery(carouselElement).data('autoplayspeed'),
			autoplayTimeout	: jQuery(carouselElement).data('autoplayspeed') + 5000,
			navSpeed		: jQuery(carouselElement).data('autoplayspeed'),
			dotsSpeed		: jQuery(carouselElement).data('autoplayspeed'),
			dragEndSpeed	: jQuery(carouselElement).data('autoplayspeed'),
			margin			: 30,
			items			: columns,
			responsiveClass	: true,
			responsive		: {
				1199 : {
					items	: responsive_items[0],
				},
				991	 : {
					items	: responsive_items[1],
				},
				767	 : {
					items	: responsive_items[2],
				},
				575	 : {
					items	: responsive_items[3],
				},
				0	 : {
					items	: responsive_items[4],
				}
			}
		};

		// gap - margin
		if( typeof margin_val == "string" && margin_val!='' ){
			margin_val = margin_val.replace( 'px', '');
			margin_val = parseInt(margin_val);
			car_options['margin'] = margin_val;
		}

		// apply carousel effect with options
		var cspt_owl = jQuery( posts_wrapper_class, carouselElement).removeClass('row multi-columns-row').addClass('owl-carousel').owlCarousel( car_options );

		jQuery('.cspt-carousel-prev', carouselElement).click(function(event) {
			event.preventDefault();
			cspt_owl.trigger('prev.owl.carousel', [jQuery(carouselElement).data('autoplayspeed')]);

		});
		jQuery('.cspt-carousel-next', carouselElement).click(function(event) {
			event.preventDefault();
			cspt_owl.trigger('next.owl.carousel', [jQuery(carouselElement).data('autoplayspeed')]);
		});

	});
};

/* ====================================== */
/* Service in style 2
/* ====================================== */
var cspt_set_service_right_column = function() {
	setTimeout(function(){
		jQuery( '.cspt-element-service-style-2' ).each(function(){
			var thisele = jQuery(this);
			if( jQuery(this).closest('.elementor-element.elementor-section-stretched.elementor-section-full_width') ){
				var body_width = jQuery( 'body' ).outerWidth();
				var container_width = jQuery( '.cspt-container', thisele ).outerWidth();
				var padding_left = ( body_width - container_width ) / 2 ;
				jQuery( '.cspt-service-2-head-area > .cspt-service-2-inner', thisele ).css( 'padding-left', padding_left );
			}
		});
	}, 100);
};

/* ====================================== */
/* Menu item count
/* ====================================== */
var cspt_menu_count = function() {
	if( jQuery('ul#cspt-top-menu > li').length>0 || jQuery('div#cspt-top-menu > ul > li').length>0 ){
		if( jQuery('ul#cspt-top-menu > li').length>0 ){
			var total_li = jQuery( 'ul#cspt-top-menu > li' ).length;
		}
		if( jQuery('div#cspt-top-menu > ul > li').length>0 ){
			var total_li = jQuery( 'div#cspt-top-menu > ul > li' ).length;
		}
		if( total_li > 6 ){
			jQuery('#site-navigation').addClass('cspt-bigger-menu');
		}
	}
}

/* ====================================== */
/* Animate on scroll : Number rotator
/* ====================================== */
var cspt_number_rotate = function() {
	jQuery(".cspt-number-rotate").each(function() {
		var self      = jQuery(this);
		var delay     = (self.data("appear-animation-delay") ? self.data("appear-animation-delay") : 0);
		var animation = self.data("appear-animation");

		if( jQuery(window).width() > 959 ) {
			self.html('0');
			self.waypoint(function(direction) {
				if( !self.hasClass('completed') ){
					var from     = self.data('from');
					var to       = self.data('to');
					var interval = self.data('interval');
					self.numinate({
						format: '%counter%',
						from: from,
						to: to,
						runningInterval: 2000,
						stepUnit: interval,
						onComplete: function(elem) {
							self.addClass('completed');
						}
					});
				}
			}, { offset:'85%' });
		} else {
			if( animation == 'animateWidth' ) {
				self.css('width', self.data("width"));
			}
		}
	});
};

/* ====================================== */
/* Image size correction
/* ====================================== */
var cspt_img_size_correction = function() {
	setTimeout(function(){
		jQuery("img").each(function() {
			var thisimg = jQuery( this );
			var p_width = jQuery( this ).parent().width();
			var width   = jQuery( this ).attr('width');
			var height  = jQuery( this ).attr('height');
			if( (typeof width !== typeof undefined && width !== false) && (typeof height !== typeof undefined && height !== false) ){
				var ratio  = height/width;
				jQuery( this ).data('cspt-ratio', ratio);
				var real_width = jQuery( this ).width();
				var new_height = Math.round(real_width * ratio);
			}
		});
	}, 100);
};

/* ====================================== */
/* Tabs
/* ====================================== */
var cspt_tabs_element = function() {
	var tabs = '';
	var tab_number = '';
	jQuery('.cspt-tabs').each(function(){
		tabs = jQuery(this);
		jQuery('.cspt-tab-link', tabs).on('click', function(){
			if( !jQuery( this ).hasClass('cspt-tab-li-active') ){
				jQuery('.cspt-tab-link', tabs).removeClass('cspt-tab-li-active');
				jQuery( this ).addClass('cspt-tab-li-active');

				tab_number = jQuery( this ).data('cspt-tab');
				jQuery('.cspt-tab-content', tabs).removeClass('cspt-tab-active');
				jQuery('.cspt-tab-content-'+tab_number, tabs).addClass('cspt-tab-active');

			}
		});

		jQuery('.cspt-tab-content-title', tabs).on('click', function(){
			tab_number = jQuery( this ).data('cspt-tab');
			jQuery('li.cspt-tab-link[data-cspt-tab="'+tab_number+'"]').trigger('click');
		});

	});

};

var cspt_progressbar = function() {
	jQuery('.cspt-progressbar').each(function(){
		var $progressbar_ele = jQuery(this);
		jQuery(this).waypoint(function(direction) {
			var $progressbar = jQuery( '.elementor-progress-bar', $progressbar_ele );
			if( !$progressbar.hasClass('completed') ){
				$progressbar.css('width', $progressbar.data('max') + '%').addClass('completed');
			}
		}, { offset:'99%' });
	});
}

/*----  Events  ----*/

// On resize
jQuery(window).resize(function(){
	setTimeout(function() {
		cspt_sticky_header();
	}, 100);

	/* Image size correction */
	cspt_img_size_correction();

	/* Service right area in style */
	cspt_set_service_right_column();

});



// on ready
jQuery(document).ready(function(){
	cspt_box_link();
	cspt_tabs_element();
	cspt_sorting();
	cspt_back_to_top();
	cspt_sticky_header();
	cspt_navbar();
	cspt_lightbox();
	cspt_video_popup();
	cspt_testimonial();
	cspt_search_btn();
	cspt_center_logo_header_class();
	cspt_selectwrap();
	cspt_menu_count();
	setTimeout(function(){ cspt_carousel(); }, 100);
	cspt_img_size_correction();
	cspt_number_rotate();
	
	/* Service right area in style */
	cspt_set_service_right_column();
	cspt_progressbar();

});	

// on load
jQuery(window).on( 'load', function(){
	cspt_sorting();
	cspt_gallery();
	cspt_sticky_header();
	cspt_circle_progressbar();
});
