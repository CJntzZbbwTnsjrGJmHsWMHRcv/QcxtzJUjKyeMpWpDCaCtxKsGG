<div class=" cspt-static-box cspt-static-box-style-<?php echo esc_attr($style); ?>">
	<div class="cspt-contentbox">
		<?php echo cspt_esc_kses($icon_html); ?>
		<?php echo cspt_esc_kses($label_html); ?>
		<?php echo cspt_esc_kses($smalltext_html); ?>
	</div>
	<div class="cspt-imgbox">
	    <?php echo cspt_esc_kses($image_html); ?>
	</div>
</div>