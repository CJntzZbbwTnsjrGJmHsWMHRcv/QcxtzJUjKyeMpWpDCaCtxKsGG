<div class="creativesplanet-post-item">
	<div class="creativesplanet-testimonial-content">
		<?php cspt_testimonial_star_ratings(); ?>
		<blockquote class="creativesplanet-testimonial-text"><?php the_content(''); ?></blockquote>
	</div>
	<div class="creativesplanet-box-inner">
		<div class="creativesplanet-box-desc d-flex align-items-center">
			<div class="creativesplanet-box-img"><?php cspt_get_featured_data( array( 'size' => 'thumbnail' ) ); ?></div>
			<div class="creativesplanet-box-author">
				<h3 class="creativesplanet-box-title"><?php echo get_the_title(); ?></h3>
				<?php echo cspt_esc_kses($company_name_html); ?>
			</div>
		</div>
	</div>
</div>