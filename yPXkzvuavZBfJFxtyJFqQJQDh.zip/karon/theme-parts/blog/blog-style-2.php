<div class="post-item">
	<div class="cspt-featured-container">
		<?php cspt_get_featured_data( array( 'size' => 'cspt-img-770x500' ) ); ?>	 			
	</div>
	<div class="creativesplanet-box-content">	
		<div class="cspt-meta-category"><?php echo get_the_category_list( ', ' ); ?></div>
		<div class="cspt-meta-container">	
			<?php
			$catlist = get_the_category_list( ', ' );
			if( !empty($catlist) ) : ?>				
			<?php endif; ?>
		</div>
		<div class="creativesplanet-box-desc">
			<h3 class="cspt-post-title"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
			<div class="cspt-post-footer d-flex align-items-center">
				<div class="cspt-meta-author-wrapper cspt-meta-line">					
					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" title="<?php printf( esc_attr__('Posted by %1$s','karon'), get_the_author() ); ?>" rel="author"> <?php printf( esc_html__( 'by %1$s', 'karon' ), get_the_author() ); ?></a>
				</div>
				<div class="cspt-meta-date-wrapper cspt-meta-line">					
					<div class="cspt-meta-date"> <?php echo get_the_date( 'M d, Y' ); ?><span></span></div>	
				</div>
			</div>
		</div>
	</div>
</div>
