<div class="cspt-pricing-table-box">
	<div class="creativesplanet-ptable-price-head">
		<?php echo cspt_esc_kses($featured); ?>
		<?php echo cspt_esc_kses($icon); ?>
		<?php echo cspt_esc_kses($heading); ?>
	</div>	
	<div class="creativesplanet-ptable-price-w">
		<?php echo cspt_esc_kses($price); ?>
		<?php echo cspt_esc_kses($frequency); ?>
	</div>
	<div class="cspt-ptable-lines-w">
		<?php echo cspt_esc_kses($lines_html); ?>
	</div>	
	<?php echo cspt_esc_kses($button); ?>
</div>