<div class="cspt-ihbox-box">
	<?php echo cspt_esc_kses( $icon_html ); ?>
	<div class="cspt-ihbox-contents">
		<?php echo cspt_esc_kses( $subtitle_html ); ?>
		<?php echo cspt_esc_kses( $title_html ); ?>
		<?php echo cspt_esc_kses($desc_html); ?>
		<?php echo cspt_esc_kses($button_html); ?>
	</div><!-- .cspt-ihbox-contents -->
</div>