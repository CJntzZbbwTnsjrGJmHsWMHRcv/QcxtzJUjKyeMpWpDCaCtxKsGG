<div class="cspt-ihbox-box">
	<div class="cspt-ihbox-headingicon">
		<?php echo cspt_esc_kses( $icon_html ); ?>
		<?php echo cspt_esc_kses( $box_number_html ); ?>
		<div class="cspt-ihbox-contents">
			<?php echo cspt_esc_kses( $title_html ); ?>
			<?php echo cspt_esc_kses( $subtitle_html ); ?>
			<?php echo cspt_esc_kses($desc_html); ?>
			<?php echo cspt_esc_kses($button_html); ?>
		</div><!-- .cspt-ihbox-contents -->
	</div>
</div>
