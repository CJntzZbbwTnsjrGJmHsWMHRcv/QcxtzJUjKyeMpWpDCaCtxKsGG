<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
if( !function_exists('cspt_widgets_init_20') ){
function cspt_widgets_init_20() {
	register_sidebar( array(
		'name'          => esc_attr__( 'Blog Sidebar', 'karon' ),
		'id'            => 'cspt-sidebar-post',
		'description'   => esc_attr__( 'Add widgets here to appear in your sidebar on blog posts and archive pages.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_attr__( 'Page Sidebar', 'karon' ),
		'id'            => 'cspt-sidebar-page',
		'description'   => esc_attr__( 'Add widgets here to appear in your sidebar on pages.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
}
add_action( 'widgets_init', 'cspt_widgets_init_20', 20 );
if( !function_exists('cspt_widgets_init_22') ){
function cspt_widgets_init_22() {
	register_sidebar( array(
		'name'          => esc_attr__( 'Search Results Sidebar', 'karon' ),
		'id'            => 'cspt-sidebar-search',
		'description'   => esc_attr__( 'Add widgets here to appear on search result pages.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_attr__( 'Footer Row - 1st Column', 'karon' ),
		'id'            => 'cspt-footer-1',
		'description'   => esc_attr__( 'Add widgets here to appear in your footer.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_attr__( 'Footer Row - 2nd Column', 'karon' ),
		'id'            => 'cspt-footer-2',
		'description'   => esc_attr__( 'Add widgets here to appear in your footer.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_attr__( 'Footer Row - 3rd Column', 'karon' ),
		'id'            => 'cspt-footer-3',
		'description'   => esc_attr__( 'Add widgets here to appear in your footer.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_attr__( 'Footer Row - 4th Column', 'karon' ),
		'id'            => 'cspt-footer-4',
		'description'   => esc_attr__( 'Add widgets here to appear in your footer.', 'karon' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
}
add_action( 'widgets_init', 'cspt_widgets_init_22', 22 );

/**
 * Customizer icon picker
 */
if( !function_exists('karon_addons_configure_customizer') ){
function karon_addons_configure_customizer(){
	if( class_exists('Kirki') ){
		/** Kirki icon picker **/
		include( get_template_directory() . '/includes/customizer/creativesplanet-icon-picker/creativesplanet-icon-picker.php' );
	}
}
}
add_action( 'init', 'karon_addons_configure_customizer' );

/**
 *  Disable Legacy mode
 */
if( !function_exists('cspt_elementor_set_legacy_mode') ){
function cspt_elementor_set_legacy_mode(){
	$optimized_dom_output = get_option( 'elementor_optimized_dom_output' );
	if( $optimized_dom_output!='enabled' ){
		update_option( 'elementor_optimized_dom_output', 'enabled' );
	}
}
}
add_action( 'init', 'cspt_elementor_set_legacy_mode' );

/**
 *  Customizer options
 */
if( !function_exists('cspt_configure_customizer') ){
function cspt_configure_customizer(){
	if( class_exists('Kirki') ){
		include( get_template_directory() . '/includes/kirki-config.php' );
	}
}
}
add_action( 'init', 'cspt_configure_customizer', 99 );

/**
 *  Categories Widget - Wrap Post count in a span
 */
add_filter('wp_list_categories', 'cspt_cat_count_span');
if( !function_exists('cspt_cat_count_span') ){
function cspt_cat_count_span($links) {
	if(strpos($links, '<span class="count">') !== false){
		// WooComerce call
		$links = str_replace('<span class="count">(', '<span class="count">', $links);
		$links = str_replace(')</span>', '</span>', $links);
	} else {
		$links = str_replace('</a> (', '</a> <span>', $links);
		$links = str_replace(')', '</span>', $links);

	}
	return $links;
}
}

/**
 *  Archives Widget - Wrap Post count in a span
 */
add_filter('get_archives_link', 'cspt_archive_count_span');
if( !function_exists('cspt_archive_count_span') ){
function cspt_archive_count_span($links) {
	if( substr( trim($links), 0, 8 ) != '<option ' ){
		$links = str_replace('</a>&nbsp;(', '</a> <span>', $links);
		$links = str_replace(')', '</span>', $links);
	}
	return $links;
}
}

/**
 *  Default Enqueue scripts and styles.
 */
if( !function_exists('cspt_theme_gfonts') ){
function cspt_theme_gfonts() {
	$font_families = array();
	$gfont_family  = '';
	include( get_template_directory() . '/includes/customizer-options.php' );
	include( get_template_directory() . '/includes/gfonts-array.php' );
	foreach( $kirki_options_array as $options_key=>$options_val ){
		if( !empty( $options_val['section_fields'] ) ){
			foreach( $options_val['section_fields'] as $key=>$option ){
				if( !empty($option['type']) && $option['type']=='typography' ){
					$font_family = '';
					$value = cspt_get_base_option( $option['settings'] );
					$family = trim($value['font-family']);
					if( substr($family, -1) == ',' ){
						$family = substr($family, 0, -1);
					}
					// Repalce space with + character
					$spaces = substr_count($family, ' ');
					if( $spaces>0 ){
						for ($x = 1; $x <= $spaces; $x++) {
							$family = str_replace( ' ', '+', $family );
						} 
					}
					$variants = $value['variant'];
					if( isset($option['cspt-all-variants']) && $option['cspt-all-variants']==true ){
						$font_family = trim($value['font-family']);
						if( substr($font_family, -1) == ',' ){
							$font_family = substr($font_family, 0, -1);
						}
						if( !empty($gfonts_array[ $font_family ]['variants']) ){
							$variants = implode( ',', $gfonts_array[ $font_family ]['variants'] );
						}
					}
					$font_families[$family][] = $variants;
				}
			}
		}
	}
	if( !empty($font_families) && is_array($font_families) ){
		$x = 1;
		foreach( $font_families as $name=>$var){
			if( !empty($name) ){
				if( $x != 1 ){ $gfont_family .= '|'; }
				$var = array_unique($var);
				$gfont_family .= $name . ':'. implode(',',$var);
			}
			$x++;
		}
		if( !empty($gfont_family) ){
			$query_args = array(
				'family' => $gfont_family,
			);
			$fonts_url = add_query_arg( $query_args, esc_url('https://fonts.googleapis.com/css'), $query_args );
			wp_enqueue_style( 'cspt-all-gfonts', $fonts_url );
		}
	}
}
}
add_action( 'wp_enqueue_scripts', 'cspt_theme_gfonts' );
add_action( 'admin_enqueue_scripts', 'cspt_theme_gfonts' );
/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
if( !function_exists('cspt_pingback_header') ){
function cspt_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", get_bloginfo( 'pingback_url' ) );
	}
}
}
add_action( 'wp_head', 'cspt_pingback_header' );

/**
 * Enqueue scripts and styles.
 */
if( !function_exists('cspt_scripts') ){
function cspt_scripts() {
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	$min = '';
	if( cspt_get_base_option('min')=='1' ){
		$min = '.min';
	}

	// RTL 
	$rtl = ( is_rtl() ) ? '-rtl' : '' ;

	// Font Awesome base
	if( !wp_style_is( 'elementor-icons-shared-0', 'registered' ) ){
		wp_register_style( 'elementor-icons-shared-0', get_template_directory_uri() . '/libraries/font-awesome/css/fontawesome.min.css' );
	}
	$icon_libraries = cspt_icon_library_list();
	foreach( $icon_libraries as $library_id=>$library_data ){
		if( !wp_style_is( $library_id, 'registered' ) ){
			wp_register_style( $library_id, $library_data['css_path'] );
		}
	}

	// Bootstrap
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/libraries/bootstrap/css/bootstrap'.$rtl.'.min.css' );

	wp_register_script( 'waypoints', get_template_directory_uri() . '/libraries/waypoints/jquery.waypoints.min.js' , array( 'jquery' ) );
	wp_register_style( 'animate-css', get_template_directory_uri() . '/libraries/animate-css/animate.min.css' );

	wp_register_script( 'jquery-circle-progress', get_template_directory_uri() . '/libraries/jquery-circle-progress/circle-progress.min.js', array( 'jquery' ) );
	wp_register_script( 'numinate', get_template_directory_uri() . '/libraries/numinate/numinate.min.js', array( 'jquery' ) );

	wp_register_script( 'owl-carousel', get_template_directory_uri() . '/libraries/owl-carousel/owl.carousel.min.js' , array( 'jquery' ) );
	wp_register_style( 'owl-carousel', get_template_directory_uri() . '/libraries/owl-carousel/assets/owl.carousel.min.css' );
	wp_register_style( 'owl-carousel-theme', get_template_directory_uri() . '/libraries/owl-carousel/assets/owl.theme.default.min.css' );

	if( cspt_get_base_option('load-merged-css')!=true ){
		wp_enqueue_style( 'cspt-core-style', get_template_directory_uri() . '/css/core'.$min.'.css' );
		wp_enqueue_style( 'cspt-theme-style', get_template_directory_uri() . '/css/theme'.$min.'.css' );
	} else {
		wp_enqueue_style( 'cspt-all-style', get_template_directory_uri() . '/css/all'.$min.'.css' );
	}

	// Magnific Popup Lightbox
	wp_enqueue_script( 'magnific-popup', get_template_directory_uri() . '/libraries/magnific-popup/jquery.magnific-popup.min.js', array('jquery') );
	wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/libraries/magnific-popup/magnific-popup.css' );
	// Base icon library
	wp_enqueue_style( 'cspt-base-icons', get_template_directory_uri() . '/libraries/creativesplanet-base-icons/css/creativesplanet-base-icons.css' );
	// Sticky
	if( cspt_get_base_option('sticky-header')==true ){
		wp_enqueue_script( 'jquery-sticky', get_template_directory_uri() . '/libraries/sticky-toolkit/jquery.sticky-kit.min.js' , array('jquery') );
	}
	// Theme base scripts
	wp_enqueue_script( 'cspt-core-script', get_template_directory_uri() . '/js/core'.$min.'.js' , array('jquery') );
	wp_enqueue_script(  'cspt-section-script', get_template_directory_uri() . '/js/section'.$min.'.js', array('jquery', 'cspt-core-script') );
	// Responsive variable
	$js_array = array(
		'responsive' => cspt_get_base_option('responsive-breakpoint'),
	);
	wp_localize_script( 'cspt-core-script', 'cspt_js_variables', $js_array );
	// ballon tooltip
	wp_enqueue_style( 'balloon', get_template_directory_uri() . '/libraries/balloon/balloon.min.css' );
	// Light Slider
	wp_register_script( 'lightslider', get_template_directory_uri() . '/libraries/lightslider/js/lightslider.min.js' , array('jquery') );
	wp_register_style( 'lightslider', get_template_directory_uri() . '/libraries/lightslider/css/lightslider.min.css' );
	// Isotope
	wp_enqueue_script( 'isotope', get_template_directory_uri() . '/libraries/isotope/isotope.pkgd.min.js' , array('jquery') );
	// remove Kirki style
	wp_dequeue_style('kirki-styles');

	/******************** */

	if( function_exists('cspt_auto_css') ){
		// Addons plugin exists
		if( function_exists('is_customize_preview') && !is_customize_preview() ){
			wp_enqueue_style('cspt-dynamic-style', admin_url('admin-ajax.php').'?action=cspt_auto_css');
		} else {
			ob_start();
			include get_template_directory().'/css/theme-style.php'; // Fetching theme-style.php output and store in a variable
			$css    = ob_get_clean();
			if( cspt_get_base_option('load-merged-css')==true ){
				wp_add_inline_style( 'cspt-all-style', $css );
			} else {
				wp_add_inline_style( 'cspt-theme-style', $css );
			}
		}
	} else {
		// Addons plugin not exists
		wp_enqueue_style( 'cspt-dynamic-default-style', get_template_directory_uri() . '/css/dynamic-default-style.css' );
	}
	$min = '';
	if( cspt_get_base_option('min')=='1' ){
		$min = '.min';
	}

	wp_enqueue_style( 'cspt-responsive-style', get_template_directory_uri() . '/css/responsive'.$min.'.css' );

	global $cspt_inline_css;
	if( !empty($cspt_inline_css) ){
		if( function_exists('cspt_minify_css') ){
			$cspt_inline_css = cspt_minify_css( $cspt_inline_css );
		}
		wp_add_inline_style( 'cspt-dynamic-style', trim( $cspt_inline_css ) );
	}

	if( is_page() || is_singular() ){
		if( wp_style_is( 'elementor-post-'.get_the_ID() , 'enqueued' ) ){
			wp_dequeue_style( 'elementor-post-'.get_the_ID() );
			wp_enqueue_style( 'elementor-post-'.get_the_ID() );
		}
	}

	if( is_singular('cspt-team-member') ){
		wp_enqueue_script( 'waypoints' );
	}

	if ( defined('ELEMENTOR_VERSION') && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
		wp_enqueue_script( 'waypoints' );
		wp_enqueue_style( 'animate-css' );

		wp_enqueue_script( 'jquery-circle-progress' );
		wp_enqueue_script( 'numinate' );

		wp_enqueue_script( 'owl-carousel' );
		wp_enqueue_style( 'owl-carousel' );
		wp_enqueue_style( 'owl-carousel-theme' );

		wp_enqueue_script( 'lightslider' );
		wp_enqueue_style( 'lightslider' );
	}

}
}
add_action( 'wp_enqueue_scripts', 'cspt_scripts', 20 );

/**
 * Admin scripts and styles
 */
if( !function_exists('cspt_wp_admin_scripts_styles') ){
function cspt_wp_admin_scripts_styles() {
	wp_register_script( 'cspt-admin-script', get_template_directory_uri() . '/includes/admin-script.js', array('jquery') );
	// Admin variable
	$admin_js_array = array(
		'theme_path' => get_template_directory_uri(),
	);
	wp_localize_script( 'cspt-admin-script', 'cspt_admin_js_variables', $admin_js_array );
	wp_enqueue_style( 'cspt-admin-style', get_template_directory_uri() . '/includes/admin-style.css' );
	wp_enqueue_script( 'cspt-admin-script' );
}
}
add_action( 'admin_enqueue_scripts', 'cspt_wp_admin_scripts_styles' );

/**
 * Elementor correction for customize bug
 */
if( !function_exists('cspt_ele_correction') ){
function cspt_ele_correction() {
	if( function_exists('is_customize_preview') && is_customize_preview() ){
		if( wp_style_is( 'elementor-common', 'enqueued' ) ){
			wp_dequeue_style('elementor-common');
		}
		if( wp_style_is( 'elementor-admin', 'enqueued' ) ){
			wp_dequeue_style('elementor-admin');
		}
	}
}
}
add_action( 'admin_enqueue_scripts', 'cspt_ele_correction', 99 );

/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since Karon 1.4
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
if( !function_exists('cspt_widget_tag_cloud_args') ){
function cspt_widget_tag_cloud_args( $args ) {
	$args['largest']  = 1;
	$args['smallest'] = 1;
	$args['unit']     = 'em';
	$args['format']   = 'list';
	return $args;
}
}
add_filter( 'widget_tag_cloud_args', 'cspt_widget_tag_cloud_args' );

/*
 *  Body Tag: Class
 */
if( !function_exists('cspt_add_body_classes') ){
function cspt_add_body_classes($classes) {
	// Widget class
	$widget_class = '';
	// sidebar class
	$sidebar_class = cspt_get_base_option('sidebar-post');
	if( in_array( $sidebar_class, array('left','right') ) ){
		$widget_class = cspt_check_widget_exists('cspt-sidebar-page');
	}
	if( is_page() ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-page');
		$page_meta = get_post_meta( get_the_ID(), 'cspt-sidebar', true );
		if( !empty($page_meta) && $page_meta!='global' ){
			$sidebar_class = $page_meta;
		}
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-page');
		}
		if( function_exists('is_woocommerce') && is_woocommerce() ){
			$widget_class = '';
			$sidebar_class = cspt_get_base_option('sidebar-wc-shop');
		}
		// Curved style at slider bottom
		$slider_type	= get_post_meta( get_the_ID(), 'cspt-slider-type', true );
		$curved_style	= get_post_meta( get_the_ID(), 'cspt-slider-curved-style', true );
		if( !empty($slider_type) && $curved_style == true ){
			$classes[] = 'cspt-slider-curved-style';
		}
	} else if( function_exists('is_woocommerce') && is_woocommerce() && !is_product() ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-wc-shop');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-wc-shop');
		}
	} else if( function_exists('is_product') && is_product() ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-wc-single');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-wc-single');
		}
	} else if( is_singular() ){
		if( get_post_type()=='cspt-portfolio' ){
			$widget_class = '';
			$sidebar_class = cspt_get_base_option('sidebar-portfolio');
			$post_meta = get_post_meta( get_the_ID(), 'cspt-sidebar', true );
			if( !empty($post_meta) && $post_meta!='global' ){
				$sidebar_class = $post_meta;
			}
			if( in_array( $sidebar_class, array('left','right') ) ){
				$widget_class = cspt_check_widget_exists('cspt-sidebar-portfolio');
			}
		} else if( get_post_type()=='cspt-service' ){
			$widget_class = '';
			$sidebar_class = cspt_get_base_option('sidebar-service');
			$post_meta = get_post_meta( get_the_ID(), 'cspt-sidebar', true );
			if( !empty($post_meta) && $post_meta!='global' ){
				$sidebar_class = $post_meta;
			}
			if( in_array( $sidebar_class, array('left','right') ) ){
				$widget_class = cspt_check_widget_exists('cspt-sidebar-service');
			}
		} else if( get_post_type()=='cspt-team-member' ){
			$widget_class = '';
			$sidebar_class = cspt_get_base_option('sidebar-team-member');
			$post_meta = get_post_meta( get_the_ID(), 'cspt-sidebar', true );
			if( !empty($post_meta) && $post_meta!='global' ){
				$sidebar_class = $post_meta;
			}
			if( in_array( $sidebar_class, array('left','right') ) ){
				$widget_class = cspt_check_widget_exists('cspt-sidebar-team');
			}
		}
	} else if( is_tax('cspt-portfolio-category') ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-portfolio-category');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-portfolio-cat');
		}
	} else if( is_tax('cspt-service-category') ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-service-category');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-service-cat');
		}
	} else if( is_tax('cspt-team-group') ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-team-group');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-team-group');
		}
	} else if( is_search() ){
		$widget_class = '';
		$sidebar_class = cspt_get_base_option('sidebar-search');
		if( in_array( $sidebar_class, array('left','right') ) ){
			$widget_class = cspt_check_widget_exists('cspt-sidebar-search');
		}
	}
	// widget exists class
	if( !empty($widget_class) ){
		$classes[] = 'cspt-sidebar-no';
	} else {
		if( in_array( $sidebar_class, array('left','right') ) ){
			$classes[] = 'cspt-sidebar-exists';
		}
		$classes[] = 'cspt-sidebar-' . $sidebar_class;
	}
	return $classes;
}
}
add_filter('body_class', 'cspt_add_body_classes');

function cspt_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}
add_filter( 'comment_form_fields', 'cspt_move_comment_field_to_bottom' );

function cspt_update_comment_fields( $fields ) {
	$commenter = wp_get_current_commenter();
	$req       = get_option( 'require_name_email' );
	$aria_req  = $req ? "aria-required='true'" : '';
	$fields['author'] =
		'<div class="cspt-comment-form-input-wrapper"><p class="cspt-comment-form-input comment-form-author">
			<input id="author" name="author" type="text" placeholder="' . esc_attr__( 'Name', 'karon' ) . '" value="' . esc_attr( $commenter['comment_author'] ) .
		'" size="30" ' . $aria_req . ' />
		</p>';
	$fields['email'] =
		'<p class="cspt-comment-form-input comment-form-email">
			<input id="email" name="email" type="email" placeholder="' . esc_attr__( 'Email', 'karon' ) . '" value="' . esc_attr( $commenter['comment_author_email'] ) .
		'" size="30" ' . $aria_req . ' />
		</p>';
	$fields['url'] =
		'<p class="cspt-comment-form-input comment-form-url">
			<input id="url" name="url" type="url"  placeholder="' . esc_attr__( 'Website', 'karon' ) . '" value="' . esc_attr( $commenter['comment_author_url'] ) .
		'" size="30" />
			</p></div>';
	return $fields;
}
add_filter( 'comment_form_default_fields', 'cspt_update_comment_fields' );
function cspt_update_comment_textarea_field( $comment_field ) {
	$comment_field =
		'<p class="comment-form-comment">
		<textarea required id="comment" name="comment" placeholder="' . esc_attr__( "Enter your comment here...", 'karon' ) . '" cols="45" rows="8"></textarea>
		</p>';
	return $comment_field;
}
add_filter( 'comment_form_field_comment', 'cspt_update_comment_textarea_field' );
// Limit Posts Per Category/Archive Page
add_filter('pre_get_posts', 'cspt_limit_category_posts');
function cspt_limit_category_posts($query){
    if( is_tax( 'cspt-portfolio-category' ) && !empty($query->query['cspt-portfolio-category']) ){
		$count		= cspt_get_base_option('portfolio-cat-count');
        $query->set('posts_per_page', $count);
    } else if( is_tax( 'cspt-team-group' ) && !empty($query->query['cspt-team-group']) ){
		$count		= cspt_get_base_option('team-group-count');
        $query->set('posts_per_page', $count);
	} else if( is_tax( 'cspt-service-category' ) && !empty($query->query['cspt-service-category']) ){
		$count		= cspt_get_base_option('service-cat-count');
        $query->set('posts_per_page', $count);
    }
    return $query;
}

/**
 * Show cart contents / total Ajax
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'cspt_woocommerce_header_add_to_cart_fragment' );
if( !function_exists('cspt_woocommerce_header_add_to_cart_fragment') ){
function cspt_woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	$show_cart_amount = cspt_get_base_option('wc-show-cart-amount');

	// cart icon class
	$cart_icon		= 'cspt-base-icon-supermarket-2';
	$header_style	= cspt_get_base_option('header-style');
	if( $header_style == '1' ){
		$cart_icon	= 'cspt-base-icon-shopping-bag-1' ;
	}
	$return = '<a href="'.esc_url(wc_get_cart_url()).'" class="cspt-cart-link">
		<span class="cspt-cart-details">
		<span class="cspt-cart-icon"><i class="'.esc_attr($cart_icon).'"></i></span>
			<span class="cspt-cart-count">'.esc_html($woocommerce->cart->cart_contents_count).'</span>
		</span>';
	if( $show_cart_amount==true ) {
		$return .= cspt_esc_kses( $woocommerce->cart->get_cart_total() );
	}
	$return .= '</a>';
	$fragments['a.cspt-cart-link'] = cspt_esc_kses($return);
	return $fragments;
}
}

/**
 * Elementor core things
 */
include( get_template_directory() . '/includes/elementor-core.php' );

/**
 * Elementor global settings
 */
add_filter( 'admin_init', 'cspt_elementor_global_settings' );
if( !function_exists('cspt_elementor_global_settings') ){
function cspt_elementor_global_settings() {

	if(get_option('cspt_elementor_global_done') === false){

		// change default color
		$default_color = array (
			1 => '',
			2 => '',
			3 => '',
			4 => '',
		);
		update_option('elementor_scheme_color', $default_color );

		// change default typo
		$default_typo = array (
			1 => array (
				'font_family' => '',
				'font_weight' => '',
			),
			2 => array (
				'font_family' => '',
				'font_weight' => '',
			),
			3 => array (
				'font_family' => '',
				'font_weight' => '',
			),
			4 => array (
				'font_family' => '',
				'font_weight' => '',
			),
		);
		update_option('elementor_scheme_typography', $default_typo );

		// Set a flag if the theme activation happened
		update_option('cspt_elementor_global_done', true, '', false);
	}
}
}

/**
 * Defined classes
 */
if( !function_exists('cspt_widget_classes') ){
function cspt_widget_classes(){
	$value = get_option('cspt-widget-classes');
	if( $value != 'yes' ){
		update_option(
			'WCSSC_options',
			array (
				'show_id'			=> false,
				'type'				=> 3,
				'defined_classes'	=> 
				array (
					0 => 'cspt-two-column-menu',
				),
				'show_number'		=> true,
				'show_location'		=> true,
				'show_evenodd'		=> true,
				'fix_widget_params'	=> false,
				'filter_unique'		=> false,
				'translate_classes'	=> false,
				)
		);
		update_option('cspt-widget-classes', 'yes');
	}
}
}
add_action( 'init', 'cspt_widget_classes' );

/**
 *  Inline code generator
 */
if( !function_exists('cspt_inline_css_code_generator') ){
function cspt_inline_css_code_generator(){
	$return		= '';
	$color_css	= '';
	if( is_page() || is_singular() ){

		// Body background
		$bg_img		= get_post_meta( get_the_ID(), 'cspt-bg-img', true );
		$bg_image	= $bg_color_css = $bg_color_opacity_css = '';

		if( !empty($bg_img) ){
			$img_src			= wp_get_attachment_image_src($bg_img, 'full');
			if( !empty($img_src[0]) ){ $bg_image = $img_src[0]; }
		}

		// Background color and color-opacity
		$bg_color			= get_post_meta( get_the_ID(), 'cspt-bg-color', true );
		$bg_color_opacity	= get_post_meta( get_the_ID(), 'cspt-bg-color-opacity', true );
		if( !empty($bg_color) ){
			$bg_color_css .= 'background-color:' . $bg_color . ' !important;';
		}
		if( !empty($bg_color_opacity) ){
			$bg_color_opacity_css .= 'opacity:' . $bg_color_opacity . ' !important;';
		}

		// Generating CSS for background
		if( !empty($bg_image) ){
			$return .= 'body{background-image:url(\'' . $bg_image . '\') !important;}';
			if( !empty($bg_color_css) ){
				$return .= 'body:before{' . $bg_color_css . $bg_color_opacity_css . '}';
			}

		} else {

			if( !empty($bg_color_css) ){
				$return .= 'body{' . $bg_color_css . '}';
			}

		}

		$titlebar_img = '';
		// Check if Titlebar bg imge is set in page or post
		$titlebar_bg_img	= get_post_meta( get_the_ID(), 'cspt-titlebar-bg-img', true );
		if( !empty($titlebar_bg_img) ){
			$img_src			= wp_get_attachment_image_src($titlebar_bg_img, 'full');
			if( !empty($img_src[0]) ){ $titlebar_img = $img_src[0]; }
			$titlebar_bg_color			= get_post_meta( get_the_ID(), 'cspt-titlebar-bg-color', true );
			$titlebar_bg_color_opacity	= get_post_meta( get_the_ID(), 'cspt-titlebar-bg-color-opacity', true );
			if( !empty($titlebar_bg_color) ){
				$color_css .= 'background-color:' . $titlebar_bg_color . ' !important;';
			}
			if( !empty($titlebar_bg_color_opacity) ){
				$color_css .= 'opacity:' . $titlebar_bg_color_opacity . ' !important;';
			}
		} else {
			// If not than check now if fetaured img as titlebar bg option is enabled or not
			$titlebar_bg_featured = cspt_get_base_option('titlebar-bg-featured');
			if( !empty($titlebar_bg_featured) && is_array($titlebar_bg_featured) ){
				if( ( is_page()							&& in_array( 'page', $titlebar_bg_featured ) ) ||
					( is_singular('post')				&& in_array( 'post', $titlebar_bg_featured ) ) ||
					( is_singular('cspt-portfolio')		&& in_array( 'cspt-portfolio',   $titlebar_bg_featured ) ) ||
					( is_singular('cspt-team-member')	&& in_array( 'cspt-team-member', $titlebar_bg_featured ) ) ||
					( is_singular('cspt-testimonial')	&& in_array( 'cspt-testimonial', $titlebar_bg_featured ) ) ||
					( is_singular('cspt-service')		&& in_array( 'cspt-service',     $titlebar_bg_featured ) )
				){
					if( has_post_thumbnail() ){
						$titlebar_img = get_the_post_thumbnail_url( get_the_ID() , 'full' );
					}
				}
			}
		}
		// Titlebar bg
		if( !empty($titlebar_img) ){
			$return .= '.cspt-title-bar-wrapper{background-image:url(\'' . $titlebar_img . '\') !important;}';
			if( !empty($color_css) ){
				$return .= '.cspt-title-bar-wrapper:before{' . $color_css . '}';
			}
		}
		// Titlebar BG Color
		$titlebar_bg_color	= get_post_meta( get_the_ID(), 'cspt-titlebar-bg-color', true );
		if( !empty($titlebar_bg_color) ){
			$opacity = get_post_meta( get_the_ID(), 'cspt-titlebar-bg-color-opacity', true );
			if( empty($opacity) ){ $opacity = '0.5'; }
			$return .= '.cspt-title-bar-wrapper:after{background-color:' . cspt_hex2rgb($titlebar_bg_color, $opacity ) . ' !important;}';
		}
	}
	if( !empty($return) ){
		cspt_inline_css( $return );
	}
}
}
add_action( 'wp', 'cspt_inline_css_code_generator' );

/**
 * Register a custom menu page.
 */
if( !function_exists('cspt_register_my_custom_menu_page') ){
function cspt_register_my_custom_menu_page() {
	add_menu_page(
		esc_attr__( 'Karon Options', 'karon' ),
		esc_attr__( 'Karon Options', 'karon' ),
		'manage_options',
		esc_url( site_url() . '/wp-admin/customize.php' ),
		'',
		esc_url( get_template_directory_uri() . '/images/customize-icon.png' ),
		6
	);
}
}
add_action( 'admin_menu', 'cspt_register_my_custom_menu_page' );