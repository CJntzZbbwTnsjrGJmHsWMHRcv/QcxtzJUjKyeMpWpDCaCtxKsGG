<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package WordPress
 * @subpackage Karon
 * @since 1.0
 * @version 1.2
 */

$footer_widget_columns	= cspt_footer_widget_columns(); // array
$widget_exists			= $footer_widget_columns[0];
$footer_columns			= $footer_widget_columns[1];
$footer_column			= $footer_widget_columns[2];

?>
				<?php if( cspt_check_sidebar() == true ){ ?>
					</div><!-- .row -->
				<?php } ?>
				</div><!-- #content -->
			</div><!-- .site-content-wrap -->
		<footer id="colophon" class="cspt-footer-section site-footer <?php cspt_footer_classes(); ?>">

			<div class="cspt-footer-section cspt-footer-big-area-wrapper cspt-bg-color-transparent">
				<div class="footer-wrap cspt-footer-big-area">
					<div class="container">
						<div class="row align-items-center cspt-bg-color-globalcolor">
							<?php cspt_footer_boxes_area(); ?>
						</div>

					</div>
				</div>
			</div>

			<?php if( $widget_exists==true ) : ?>
			<div class="cspt-footer-section footer-wrap cspt-footer-widget-area <?php cspt_footer_widget_classes(); ?>">
				<div class="container">
					<div class="row">
						<?php 
						$col = 1;
						foreach( $footer_columns as $column ){
							$class = ( $footer_column == '3-3-3-3' ) ? 'col-md-6 col-lg-3' : 'col-md-'.$column ;
							if ( is_active_sidebar( 'cspt-footer-'.$col ) ) { ?>
								<div class="cspt-footer-widget cspt-footer-widget-col-<?php echo esc_attr($col); ?> <?php echo esc_attr($class); ?>">
									<?php dynamic_sidebar( 'cspt-footer-'.$col ); ?>
								</div><!-- .cspt-footer-widget -->
							<?php };
							$col++;
						} // end foreach
						?>
					</div><!-- .row -->
				</div>	
			</div>
			<?php endif; ?>
			<div class="cspt-footer-section cspt-footer-text-area <?php cspt_footer_copyright_classes(); ?>">
				<div class="container">
					<div class="cspt-footer-text-inner">
						<div class="row">
							<?php cspt_footer_copyright_area(); ?>
						</div>						
					</div>	

				</div>
			</div>
		</footer><!-- #colophon -->
	</div><!-- .site-content-contain -->
</div><!-- #page -->
<a href="#" class="scroll-to-top"><i class="cspt-base-icon-up-open-big"></i></a>
<?php wp_footer(); ?>
</body>
</html>
